import { db } from "./db";
import { savedAnalyses, stockAnalyses, cryptoAnalyses, commodityAnalyses, type InsertSavedAnalysis, type SavedAnalysis } from "../shared/schema";
import { eq, and, desc } from "drizzle-orm";

export async function saveAnalysis(data: InsertSavedAnalysis): Promise<SavedAnalysis> {
  const [analysis] = await db.insert(savedAnalyses).values(data).returning();
  return analysis;
}

export async function getUserAnalyses(userId: number): Promise<SavedAnalysis[]> {
  return db.select()
    .from(savedAnalyses)
    .where(eq(savedAnalyses.userId, userId))
    .orderBy(desc(savedAnalyses.createdAt))
    .limit(50);
}

export async function getAnalysisById(id: number, userId: number): Promise<SavedAnalysis | null> {
  const [analysis] = await db.select()
    .from(savedAnalyses)
    .where(eq(savedAnalyses.id, id));
  if (!analysis || analysis.userId !== userId) {
    return null;
  }
  return analysis;
}

export async function deleteAnalysis(id: number, userId: number): Promise<boolean> {
  const analysis = await getAnalysisById(id, userId);
  if (!analysis) {
    return false;
  }
  await db.delete(savedAnalyses).where(eq(savedAnalyses.id, id));
  return true;
}

export async function getAnalysisCount(userId: number): Promise<number> {
  const analyses = await db.select()
    .from(savedAnalyses)
    .where(eq(savedAnalyses.userId, userId));
  return analyses.length;
}

export async function getStockAnalyses(userId: number) {
  return await db.select()
    .from(stockAnalyses)
    .where(eq(stockAnalyses.userId, userId))
    .orderBy(desc(stockAnalyses.createdAt));
}

export async function saveStockAnalysis(data: any) {
  const [analysis] = await db.insert(stockAnalyses).values(data).returning();
  return analysis;
}

export async function deleteStockAnalysis(id: number, userId: number) {
  const result = await db.delete(stockAnalyses)
    .where(and(eq(stockAnalyses.id, id), eq(stockAnalyses.userId, userId)))
    .returning();
  return result.length > 0;
}

export async function getCryptoAnalyses(userId: number) {
  return await db.select()
    .from(cryptoAnalyses)
    .where(eq(cryptoAnalyses.userId, userId))
    .orderBy(desc(cryptoAnalyses.createdAt));
}

export async function saveCryptoAnalysis(data: any) {
  const [analysis] = await db.insert(cryptoAnalyses).values(data).returning();
  return analysis;
}

export async function deleteCryptoAnalysis(id: number, userId: number) {
  const result = await db.delete(cryptoAnalyses)
    .where(and(eq(cryptoAnalyses.id, id), eq(cryptoAnalyses.userId, userId)))
    .returning();
  return result.length > 0;
}

export async function getCommodityAnalyses(userId: number) {
  return await db.select()
    .from(commodityAnalyses)
    .where(eq(commodityAnalyses.userId, userId))
    .orderBy(desc(commodityAnalyses.createdAt));
}

export async function saveCommodityAnalysis(data: any) {
  const [analysis] = await db.insert(commodityAnalyses).values(data).returning();
  return analysis;
}

export async function deleteCommodityAnalysis(id: number, userId: number) {
  const result = await db.delete(commodityAnalyses)
    .where(and(eq(commodityAnalyses.id, id), eq(commodityAnalyses.userId, userId)))
    .returning();
  return result.length > 0;
}
