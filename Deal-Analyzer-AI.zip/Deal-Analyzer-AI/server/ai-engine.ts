import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export type AssetType = "real_estate" | "stock" | "crypto" | "commodity";

export interface DealLensScores {
  overall: number;
  risk: number;
  yield: number;
  growth: number;
  liquidity: number;
}

export interface AIAnalysisResult {
  scores: DealLensScores;
  verdict: "Good" | "Neutral" | "Bad";
  riskLevel: "Low" | "Medium" | "High";
  recommendation: "Buy" | "Hold" | "Avoid";
  summary: string;
  strengths: string[];
  weaknesses: string[];
  risks: string[];
  sensitivity: { factor: string; impact: string }[];
  confidenceLevel: number;
}

interface RealEstateInput {
  price: number;
  location: string;
  propertyType: string;
  units: number;
  weeklyRent: number;
  expensesPercent: number;
  growthPercent: number;
  period: number;
  grossYield: number;
  netYield: number;
  cashFlow: number;
  suburb?: string;
  medianPrice?: number;
  medianRent?: number;
}

interface StockInput {
  ticker: string;
  companyName: string;
  currentPrice: number;
  peRatio?: number;
  dividendYield?: number;
  marketCap?: number;
  sector?: string;
  fiftyTwoWeekHigh?: number;
  fiftyTwoWeekLow?: number;
}

interface CryptoInput {
  symbol: string;
  name: string;
  currentPrice: number;
  marketCap?: number;
  volume24h?: number;
  priceChange24h?: number;
  priceChange7d?: number;
  allTimeHigh?: number;
}

interface CommodityInput {
  name: string;
  type: string;
  currentPrice: number;
  unit: string;
  priceChange30d?: number;
  priceChange1y?: number;
}

function calculateRealEstateScore(input: RealEstateInput): DealLensScores {
  let yieldScore = Math.min(100, Math.max(0, input.grossYield * 12));
  let riskScore = 100 - Math.min(100, Math.max(0, (input.expensesPercent - 20) * 2));
  let growthScore = Math.min(100, Math.max(0, input.growthPercent * 10));
  let liquidityScore = 30;
  
  if (input.medianPrice && input.price) {
    const priceDiff = ((input.medianPrice - input.price) / input.medianPrice) * 100;
    yieldScore += Math.min(20, Math.max(-20, priceDiff / 2));
  }
  
  if (input.cashFlow > 0) {
    yieldScore = Math.min(100, yieldScore + 10);
  }

  yieldScore = Math.min(100, Math.max(0, yieldScore));
  riskScore = Math.min(100, Math.max(0, riskScore));
  growthScore = Math.min(100, Math.max(0, growthScore));

  const overall = Math.round(
    yieldScore * 0.35 +
    riskScore * 0.25 +
    growthScore * 0.25 +
    liquidityScore * 0.15
  );

  return {
    overall: Math.min(100, Math.max(0, overall)),
    risk: Math.round(100 - riskScore),
    yield: Math.round(yieldScore),
    growth: Math.round(growthScore),
    liquidity: liquidityScore,
  };
}

function calculateStockScore(input: StockInput): DealLensScores {
  let yieldScore = input.dividendYield ? Math.min(100, input.dividendYield * 15) : 20;
  let riskScore = 50;
  let growthScore = 50;
  let liquidityScore = 85;

  if (input.peRatio) {
    if (input.peRatio < 15) growthScore += 20;
    else if (input.peRatio > 30) riskScore += 20;
  }

  if (input.fiftyTwoWeekHigh && input.fiftyTwoWeekLow && input.currentPrice) {
    const range = input.fiftyTwoWeekHigh - input.fiftyTwoWeekLow;
    const position = (input.currentPrice - input.fiftyTwoWeekLow) / range;
    if (position < 0.3) growthScore += 15;
    else if (position > 0.9) riskScore += 15;
  }

  if (input.marketCap) {
    if (input.marketCap > 100000000000) {
      riskScore -= 15;
      liquidityScore = 95;
    } else if (input.marketCap < 1000000000) {
      riskScore += 15;
      liquidityScore = 60;
    }
  }

  const overall = Math.round(
    yieldScore * 0.25 +
    (100 - riskScore) * 0.30 +
    growthScore * 0.30 +
    liquidityScore * 0.15
  );

  return {
    overall: Math.min(100, Math.max(0, overall)),
    risk: Math.min(100, Math.max(0, riskScore)),
    yield: Math.min(100, Math.max(0, yieldScore)),
    growth: Math.min(100, Math.max(0, growthScore)),
    liquidity: liquidityScore,
  };
}

function calculateCryptoScore(input: CryptoInput): DealLensScores {
  let riskScore = 70;
  let yieldScore = 0;
  let growthScore = 50;
  let liquidityScore = 80;

  if (input.priceChange7d) {
    if (input.priceChange7d > 20) riskScore += 15;
    else if (input.priceChange7d < -20) riskScore += 10;
    growthScore += Math.min(30, Math.max(-30, input.priceChange7d));
  }

  if (input.marketCap) {
    if (input.marketCap > 50000000000) {
      riskScore -= 20;
      liquidityScore = 95;
    } else if (input.marketCap < 1000000000) {
      riskScore += 15;
      liquidityScore = 50;
    }
  }

  if (input.allTimeHigh && input.currentPrice) {
    const athRatio = input.currentPrice / input.allTimeHigh;
    if (athRatio < 0.3) growthScore += 20;
    else if (athRatio > 0.9) riskScore += 10;
  }

  const overall = Math.round(
    (100 - riskScore) * 0.40 +
    growthScore * 0.40 +
    liquidityScore * 0.20
  );

  return {
    overall: Math.min(100, Math.max(0, overall)),
    risk: Math.min(100, Math.max(0, riskScore)),
    yield: 0,
    growth: Math.min(100, Math.max(0, growthScore)),
    liquidity: liquidityScore,
  };
}

function calculateCommodityScore(input: CommodityInput): DealLensScores {
  let riskScore = 40;
  let yieldScore = 0;
  let growthScore = 50;
  let liquidityScore = 70;

  if (input.priceChange1y) {
    growthScore += Math.min(25, Math.max(-25, input.priceChange1y / 2));
    if (Math.abs(input.priceChange1y) > 30) riskScore += 15;
  }

  if (input.type === "precious_metal") {
    riskScore -= 15;
    liquidityScore = 80;
  } else if (input.type === "energy") {
    riskScore += 10;
    liquidityScore = 85;
  } else if (input.type === "agricultural") {
    riskScore += 5;
    liquidityScore = 60;
  }

  const overall = Math.round(
    (100 - riskScore) * 0.35 +
    growthScore * 0.35 +
    liquidityScore * 0.30
  );

  return {
    overall: Math.min(100, Math.max(0, overall)),
    risk: Math.min(100, Math.max(0, riskScore)),
    yield: 0,
    growth: Math.min(100, Math.max(0, growthScore)),
    liquidity: liquidityScore,
  };
}

export async function analyzeAsset(
  assetType: AssetType,
  data: RealEstateInput | StockInput | CryptoInput | CommodityInput
): Promise<AIAnalysisResult> {
  let scores: DealLensScores;
  let prompt: string;

  switch (assetType) {
    case "real_estate":
      scores = calculateRealEstateScore(data as RealEstateInput);
      prompt = buildRealEstatePrompt(data as RealEstateInput, scores);
      break;
    case "stock":
      scores = calculateStockScore(data as StockInput);
      prompt = buildStockPrompt(data as StockInput, scores);
      break;
    case "crypto":
      scores = calculateCryptoScore(data as CryptoInput);
      prompt = buildCryptoPrompt(data as CryptoInput, scores);
      break;
    case "commodity":
      scores = calculateCommodityScore(data as CommodityInput);
      prompt = buildCommodityPrompt(data as CommodityInput, scores);
      break;
    default:
      throw new Error(`Unknown asset type: ${assetType}`);
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5-mini",
      messages: [
        {
          role: "system",
          content: `You are a professional investment analyst. Respond ONLY with valid JSON matching the exact schema requested. Be objective and data-driven. No disclaimers in the analysis content.`,
        },
        { role: "user", content: prompt },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 1500,
    });

    const content = response.choices[0]?.message?.content;
    if (!content) throw new Error("No AI response");

    const aiResult = JSON.parse(content);
    
    return {
      scores,
      verdict: validateVerdict(aiResult.verdict),
      riskLevel: validateRiskLevel(aiResult.riskLevel),
      recommendation: validateRecommendation(aiResult.recommendation),
      summary: aiResult.summary || "Analysis complete.",
      strengths: ensureArray(aiResult.strengths, 3),
      weaknesses: ensureArray(aiResult.weaknesses, 2),
      risks: ensureArray(aiResult.risks, 2),
      sensitivity: aiResult.sensitivity || [],
      confidenceLevel: Math.min(1, Math.max(0, aiResult.confidenceLevel || 0.8)),
    };
  } catch (error) {
    console.error("AI analysis error:", error);
    return getFallbackAnalysis(assetType, scores);
  }
}

function buildRealEstatePrompt(data: RealEstateInput, scores: DealLensScores): string {
  return `Analyze this Australian property investment:

Property: ${data.location}
Type: ${data.propertyType}, ${data.units} unit(s)
Price: $${data.price.toLocaleString()}
Weekly Rent: $${data.weeklyRent}/unit
Gross Yield: ${data.grossYield.toFixed(2)}%
Net Yield: ${data.netYield.toFixed(2)}%
Annual Cash Flow: $${data.cashFlow.toLocaleString()}
Expected Growth: ${data.growthPercent}% p.a.
Investment Period: ${data.period} years
${data.medianPrice ? `Area Median Price: $${data.medianPrice.toLocaleString()}` : ""}
${data.medianRent ? `Area Median Rent: $${data.medianRent.toLocaleString()}` : ""}

DealLens Scores: Overall ${scores.overall}/100, Yield ${scores.yield}/100, Risk ${scores.risk}/100, Growth ${scores.growth}/100

Respond with JSON:
{
  "verdict": "Good" | "Neutral" | "Bad",
  "riskLevel": "Low" | "Medium" | "High",
  "recommendation": "Buy" | "Hold" | "Avoid",
  "summary": "2-3 sentence summary",
  "strengths": ["strength1", "strength2", "strength3"],
  "weaknesses": ["weakness1", "weakness2"],
  "risks": ["risk1", "risk2"],
  "sensitivity": [{"factor": "Interest Rates +1%", "impact": "Cash flow -$X/yr"}, {"factor": "Vacancy 2 weeks", "impact": "..."}],
  "confidenceLevel": 0.0-1.0
}`;
}

function buildStockPrompt(data: StockInput, scores: DealLensScores): string {
  return `Analyze this stock investment:

Ticker: ${data.ticker}
Company: ${data.companyName}
Current Price: $${data.currentPrice.toFixed(2)}
${data.peRatio ? `P/E Ratio: ${data.peRatio.toFixed(2)}` : ""}
${data.dividendYield ? `Dividend Yield: ${data.dividendYield.toFixed(2)}%` : ""}
${data.marketCap ? `Market Cap: $${(data.marketCap / 1e9).toFixed(2)}B` : ""}
${data.sector ? `Sector: ${data.sector}` : ""}
${data.fiftyTwoWeekHigh ? `52W Range: $${data.fiftyTwoWeekLow?.toFixed(2)} - $${data.fiftyTwoWeekHigh.toFixed(2)}` : ""}

DealLens Scores: Overall ${scores.overall}/100, Yield ${scores.yield}/100, Risk ${scores.risk}/100, Growth ${scores.growth}/100

Respond with JSON:
{
  "verdict": "Good" | "Neutral" | "Bad",
  "riskLevel": "Low" | "Medium" | "High",
  "recommendation": "Buy" | "Hold" | "Avoid",
  "summary": "2-3 sentence summary",
  "strengths": ["strength1", "strength2", "strength3"],
  "weaknesses": ["weakness1", "weakness2"],
  "risks": ["risk1", "risk2"],
  "sensitivity": [{"factor": "Market downturn 10%", "impact": "..."}, {"factor": "Sector rotation", "impact": "..."}],
  "confidenceLevel": 0.0-1.0
}`;
}

function buildCryptoPrompt(data: CryptoInput, scores: DealLensScores): string {
  return `Analyze this cryptocurrency investment:

Symbol: ${data.symbol}
Name: ${data.name}
Current Price: $${data.currentPrice.toFixed(4)}
${data.marketCap ? `Market Cap: $${(data.marketCap / 1e9).toFixed(2)}B` : ""}
${data.volume24h ? `24h Volume: $${(data.volume24h / 1e6).toFixed(2)}M` : ""}
${data.priceChange24h !== undefined ? `24h Change: ${data.priceChange24h.toFixed(2)}%` : ""}
${data.priceChange7d !== undefined ? `7d Change: ${data.priceChange7d.toFixed(2)}%` : ""}
${data.allTimeHigh ? `All-Time High: $${data.allTimeHigh.toFixed(4)}` : ""}

DealLens Scores: Overall ${scores.overall}/100, Risk ${scores.risk}/100, Growth ${scores.growth}/100

Respond with JSON:
{
  "verdict": "Good" | "Neutral" | "Bad",
  "riskLevel": "Low" | "Medium" | "High",
  "recommendation": "Buy" | "Hold" | "Avoid",
  "summary": "2-3 sentence summary",
  "strengths": ["strength1", "strength2", "strength3"],
  "weaknesses": ["weakness1", "weakness2"],
  "risks": ["risk1", "risk2"],
  "sensitivity": [{"factor": "Market volatility spike", "impact": "..."}, {"factor": "Regulatory action", "impact": "..."}],
  "confidenceLevel": 0.0-1.0
}`;
}

function buildCommodityPrompt(data: CommodityInput, scores: DealLensScores): string {
  return `Analyze this commodity investment:

Name: ${data.name}
Type: ${data.type}
Current Price: $${data.currentPrice.toFixed(2)}/${data.unit}
${data.priceChange30d !== undefined ? `30d Change: ${data.priceChange30d.toFixed(2)}%` : ""}
${data.priceChange1y !== undefined ? `1Y Change: ${data.priceChange1y.toFixed(2)}%` : ""}

DealLens Scores: Overall ${scores.overall}/100, Risk ${scores.risk}/100, Growth ${scores.growth}/100

Respond with JSON:
{
  "verdict": "Good" | "Neutral" | "Bad",
  "riskLevel": "Low" | "Medium" | "High",
  "recommendation": "Buy" | "Hold" | "Avoid",
  "summary": "2-3 sentence summary",
  "strengths": ["strength1", "strength2", "strength3"],
  "weaknesses": ["weakness1", "weakness2"],
  "risks": ["risk1", "risk2"],
  "sensitivity": [{"factor": "Supply disruption", "impact": "..."}, {"factor": "Dollar strength", "impact": "..."}],
  "confidenceLevel": 0.0-1.0
}`;
}

function validateVerdict(v: any): "Good" | "Neutral" | "Bad" {
  if (["Good", "Neutral", "Bad"].includes(v)) return v;
  return "Neutral";
}

function validateRiskLevel(r: any): "Low" | "Medium" | "High" {
  if (["Low", "Medium", "High"].includes(r)) return r;
  return "Medium";
}

function validateRecommendation(r: any): "Buy" | "Hold" | "Avoid" {
  if (["Buy", "Hold", "Avoid"].includes(r)) return r;
  return "Hold";
}

function ensureArray(arr: any, minLength: number): string[] {
  if (Array.isArray(arr) && arr.length >= minLength) return arr.slice(0, 5);
  return ["See detailed analysis", "Consider market conditions", "Review investment timeline"].slice(0, minLength);
}

function getFallbackAnalysis(assetType: AssetType, scores: DealLensScores): AIAnalysisResult {
  const verdict = scores.overall >= 65 ? "Good" : scores.overall >= 40 ? "Neutral" : "Bad";
  const riskLevel = scores.risk <= 35 ? "Low" : scores.risk <= 65 ? "Medium" : "High";
  const recommendation = scores.overall >= 65 ? "Buy" : scores.overall >= 40 ? "Hold" : "Avoid";

  return {
    scores,
    verdict,
    riskLevel,
    recommendation,
    summary: `DealLens Score: ${scores.overall}/100. ${verdict === "Good" ? "This asset shows strong fundamentals." : verdict === "Neutral" ? "This asset has mixed indicators." : "This asset requires careful consideration."}`,
    strengths: ["Diversification potential", "Market access", "Transparent pricing"],
    weaknesses: ["Market volatility risk", "Economic sensitivity"],
    risks: ["General market risk", "Timing risk"],
    sensitivity: [{ factor: "Market movement 10%", impact: "Portfolio value change" }],
    confidenceLevel: 0.7,
  };
}

export function calculateLocationScore(data: {
  suburb?: string;
  state?: string;
  medianPrice?: number;
  medianRent?: number;
  priceVsMedian?: number;
}): number {
  let score = 50;

  if (data.priceVsMedian !== undefined) {
    if (data.priceVsMedian < -10) score += 15;
    else if (data.priceVsMedian > 20) score -= 15;
  }

  if (data.medianRent && data.medianPrice) {
    const impliedYield = (data.medianRent * 52) / data.medianPrice * 100;
    if (impliedYield > 5) score += 10;
    else if (impliedYield < 3) score -= 10;
  }

  const growthStates = ["NSW", "VIC", "QLD"];
  if (data.state && growthStates.includes(data.state.toUpperCase())) {
    score += 5;
  }

  return Math.min(100, Math.max(0, score));
}
