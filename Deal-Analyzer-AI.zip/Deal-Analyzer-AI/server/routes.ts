import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "node:http";
import crypto from "crypto";
import { createUser, validateUser, createSession, validateSession, deleteSession, getUserByEmail, updateUser, getUserById, updateUserStats, updateUserBadges, createPasswordResetToken, validateResetToken, resetPassword, createUserWithGoogle, getUserByGoogleId, validateEmail, validatePassword, getPasswordStrength } from "./auth";
import { saveAnalysis, getUserAnalyses, deleteAnalysis, getAnalysisCount, getStockAnalyses, getCryptoAnalyses, getCommodityAnalyses, saveStockAnalysis, saveCryptoAnalysis, saveCommodityAnalysis } from "./storage";
import { analyzeAsset, calculateLocationScore, type AssetType } from "./ai-engine";

interface DealAnalysisRequest {
  propertyPrice: number;
  location: string;
  propertyType: "house" | "apartment" | "building";
  numberOfUnits: number;
  rentPerUnitPerWeek: number;
  expensesPercent: number;
  expectedGrowthPercent: number;
  investmentPeriod: number;
  suburb?: string;
  postcode?: string;
  state?: string;
}

interface DealCalculations {
  annualRentalIncome: number;
  annualExpenses: number;
  netAnnualCashFlow: number;
  futureValue: number;
  capitalGain: number;
  cashOnCashROI: number;
  grossYield: number;
  netYield: number;
}

function calculateDeal(data: DealAnalysisRequest): DealCalculations {
  const annualRentalIncome = data.rentPerUnitPerWeek * data.numberOfUnits * 52;
  const annualExpenses = annualRentalIncome * (data.expensesPercent / 100);
  const netAnnualCashFlow = annualRentalIncome - annualExpenses;
  const futureValue = data.propertyPrice * Math.pow(1 + data.expectedGrowthPercent / 100, data.investmentPeriod);
  const capitalGain = futureValue - data.propertyPrice;
  const cashOnCashROI = (netAnnualCashFlow / data.propertyPrice) * 100;
  const grossYield = (annualRentalIncome / data.propertyPrice) * 100;
  const netYield = (netAnnualCashFlow / data.propertyPrice) * 100;

  return {
    annualRentalIncome,
    annualExpenses,
    netAnnualCashFlow,
    futureValue,
    capitalGain,
    cashOnCashROI,
    grossYield,
    netYield,
  };
}

function validateAnalysisRequest(body: any): { valid: boolean; error?: string } {
  if (!body.propertyPrice || body.propertyPrice <= 0) {
    return { valid: false, error: "Property price must be a positive number" };
  }
  if (!body.location || typeof body.location !== "string") {
    return { valid: false, error: "Location is required" };
  }
  if (!body.rentPerUnitPerWeek || body.rentPerUnitPerWeek <= 0) {
    return { valid: false, error: "Weekly rent must be a positive number" };
  }
  if (body.propertyPrice > 100000000) {
    return { valid: false, error: "Property price seems unrealistic (over $100M)" };
  }
  if (body.rentPerUnitPerWeek > 50000) {
    return { valid: false, error: "Weekly rent seems unrealistic (over $50,000)" };
  }
  if (body.expectedGrowthPercent > 50) {
    return { valid: false, error: "Expected growth rate seems unrealistic (over 50%)" };
  }
  return { valid: true };
}

async function authMiddleware(req: Request, res: Response, next: NextFunction) {
  const sessionId = req.headers.authorization?.replace("Bearer ", "");
  if (!sessionId) {
    return res.status(401).json({ error: "Authentication required" });
  }
  
  const user = await validateSession(sessionId);
  if (!user) {
    return res.status(401).json({ error: "Invalid or expired session" });
  }
  
  (req as any).user = user;
  (req as any).sessionId = sessionId;
  next();
}

function generateShareToken(): string {
  return crypto.randomBytes(16).toString("hex");
}

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/auth/signup", async (req: Request, res: Response) => {
    try {
      const { email, password, name } = req.body;
      
      if (!email || !password || !name) {
        return res.status(400).json({ error: "Email, password, and name are required" });
      }
      
      const user = await createUser(email, password, name);
      const session = await createSession(user.id, false);
      
      res.json({
        user: { id: user.id, email: user.email, name: user.name },
        sessionId: session.sessionId,
        expiresAt: session.expiresAt,
      });
    } catch (error: any) {
      console.error("Signup error:", error);
      res.status(400).json({ error: error.message || "Failed to create account" });
    }
  });

  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { email, password, rememberMe } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
      }
      
      const user = await validateUser(email, password);
      if (!user) {
        return res.status(401).json({ error: "Invalid email or password" });
      }
      
      const session = await createSession(user.id, rememberMe || false);
      
      res.json({
        user: { id: user.id, email: user.email, name: user.name },
        sessionId: session.sessionId,
        expiresAt: session.expiresAt,
      });
    } catch (error: any) {
      console.error("Login error:", error);
      res.status(400).json({ error: error.message || "Failed to login" });
    }
  });

  app.post("/api/auth/logout", async (req: Request, res: Response) => {
    try {
      const sessionId = req.headers.authorization?.replace("Bearer ", "");
      if (sessionId) {
        await deleteSession(sessionId);
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Logout error:", error);
      res.status(500).json({ error: "Failed to logout" });
    }
  });

  app.post("/api/auth/forgot-password", async (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ error: "Email is required" });
      }
      
      const token = await createPasswordResetToken(email);
      
      res.json({ 
        success: true, 
        message: "If an account exists with this email, you will receive a password reset link.",
        token: token || undefined
      });
    } catch (error: any) {
      console.error("Forgot password error:", error);
      res.status(400).json({ error: error.message || "Failed to process request" });
    }
  });

  app.post("/api/auth/verify-reset-token", async (req: Request, res: Response) => {
    try {
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({ error: "Reset token is required" });
      }
      
      const userId = await validateResetToken(token);
      
      if (!userId) {
        return res.status(400).json({ error: "Invalid or expired reset link" });
      }
      
      res.json({ valid: true });
    } catch (error) {
      console.error("Verify reset token error:", error);
      res.status(500).json({ error: "Failed to verify token" });
    }
  });

  app.post("/api/auth/reset-password", async (req: Request, res: Response) => {
    try {
      const { token, password } = req.body;
      
      if (!token || !password) {
        return res.status(400).json({ error: "Token and password are required" });
      }
      
      await resetPassword(token, password);
      
      res.json({ success: true, message: "Password has been reset successfully" });
    } catch (error: any) {
      console.error("Reset password error:", error);
      res.status(400).json({ error: error.message || "Failed to reset password" });
    }
  });

  app.post("/api/auth/google", async (req: Request, res: Response) => {
    try {
      const { email, name, googleId, avatarUrl, rememberMe } = req.body;
      
      if (!email || !name || !googleId) {
        return res.status(400).json({ error: "Email, name, and Google ID are required" });
      }
      
      const user = await createUserWithGoogle(email, name, googleId, avatarUrl);
      const session = await createSession(user.id, rememberMe || false);
      
      res.json({
        user: { id: user.id, email: user.email, name: user.name, avatarUrl: user.avatarUrl },
        sessionId: session.sessionId,
        expiresAt: session.expiresAt,
      });
    } catch (error: any) {
      console.error("Google auth error:", error);
      res.status(400).json({ error: error.message || "Failed to authenticate with Google" });
    }
  });

  app.get("/api/auth/validate-password", (req: Request, res: Response) => {
    const password = req.query.password as string || "";
    const validation = validatePassword(password);
    const strength = getPasswordStrength(password);
    
    res.json({
      isValid: validation.isValid,
      errors: validation.errors,
      strength
    });
  });

  app.get("/api/auth/me", authMiddleware, async (req: Request, res: Response) => {
    const user = (req as any).user;
    res.json({ id: user.id, email: user.email, name: user.name });
  });

  app.put("/api/auth/profile", authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const { name, email } = req.body;
      
      if (email && email !== user.email) {
        const existing = await getUserByEmail(email);
        if (existing) {
          return res.status(400).json({ error: "Email already in use" });
        }
      }
      
      const updated = await updateUser(user.id, { name, email });
      res.json({ id: updated.id, email: updated.email, name: updated.name });
    } catch (error) {
      console.error("Profile update error:", error);
      res.status(500).json({ error: "Failed to update profile" });
    }
  });

  app.get("/api/user/stats", authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const fullUser = await getUserById(user.id);
      res.json({
        propertiesAnalyzed: fullUser?.propertiesAnalyzed || 0,
        currentStreak: fullUser?.currentStreak || 0,
        badges: JSON.parse(fullUser?.badges || "[]"),
        portfolioHealthLevel: fullUser?.portfolioHealthLevel || 0,
      });
    } catch (error) {
      console.error("Get stats error:", error);
      res.status(500).json({ error: "Failed to get stats" });
    }
  });

  app.get("/api/portfolio/summary", authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const realEstate = await getUserAnalyses(user.id);
      const stocks = await getStockAnalyses(user.id);
      const crypto = await getCryptoAnalyses(user.id);
      const commodities = await getCommodityAnalyses(user.id);

      let totalValue = 0;
      let totalRealEstate = 0;
      let totalStocks = 0;
      let totalCrypto = 0;
      let totalCommodities = 0;
      let avgScore = 0;
      let scoreCount = 0;

      realEstate.forEach((a: any) => {
        totalRealEstate += a.propertyPrice || 0;
        if (a.dealLensScore) { avgScore += a.dealLensScore; scoreCount++; }
      });

      stocks.forEach((s: any) => {
        const val = (s.currentPrice || 0) * (s.quantity || 1);
        totalStocks += val;
        if (s.dealLensScore) { avgScore += s.dealLensScore; scoreCount++; }
      });

      crypto.forEach((c: any) => {
        const val = (c.currentPrice || 0) * (c.quantity || 1);
        totalCrypto += val;
        if (c.dealLensScore) { avgScore += c.dealLensScore; scoreCount++; }
      });

      commodities.forEach((co: any) => {
        const val = (co.currentPrice || 0) * (co.quantity || 1);
        totalCommodities += val;
        if (co.dealLensScore) { avgScore += co.dealLensScore; scoreCount++; }
      });

      totalValue = totalRealEstate + totalStocks + totalCrypto + totalCommodities;

      res.json({
        totalValue,
        allocation: {
          realEstate: totalRealEstate,
          stocks: totalStocks,
          crypto: totalCrypto,
          commodities: totalCommodities,
        },
        counts: {
          realEstate: realEstate.length,
          stocks: stocks.length,
          crypto: crypto.length,
          commodities: commodities.length,
        },
        averageScore: scoreCount > 0 ? Math.round(avgScore / scoreCount) : 0,
      });
    } catch (error) {
      console.error("Portfolio summary error:", error);
      res.status(500).json({ error: "Failed to get portfolio summary" });
    }
  });

  app.post("/api/calculate", async (req: Request, res: Response) => {
    try {
      const validation = validateAnalysisRequest(req.body);
      if (!validation.valid) {
        return res.status(400).json({ error: validation.error });
      }

      const data: DealAnalysisRequest = {
        propertyPrice: req.body.propertyPrice,
        location: req.body.location || "Unknown",
        propertyType: req.body.propertyType || "house",
        numberOfUnits: req.body.numberOfUnits || 1,
        rentPerUnitPerWeek: req.body.rentPerUnitPerWeek,
        expensesPercent: req.body.expensesPercent || 30,
        expectedGrowthPercent: req.body.expectedGrowthPercent || 5,
        investmentPeriod: req.body.investmentPeriod || 5,
      };

      const calculations = calculateDeal(data);
      res.json({ calculations });
    } catch (error) {
      console.error("Calculate error:", error);
      res.status(500).json({ error: "Failed to calculate" });
    }
  });

  app.post("/api/analyze", async (req: Request, res: Response) => {
    try {
      const validation = validateAnalysisRequest(req.body);
      if (!validation.valid) {
        return res.status(400).json({ error: validation.error });
      }

      const data: DealAnalysisRequest = {
        propertyPrice: req.body.propertyPrice,
        location: req.body.location,
        propertyType: req.body.propertyType || "house",
        numberOfUnits: req.body.numberOfUnits || 1,
        rentPerUnitPerWeek: req.body.rentPerUnitPerWeek,
        expensesPercent: req.body.expensesPercent || 30,
        expectedGrowthPercent: req.body.expectedGrowthPercent || 5,
        investmentPeriod: req.body.investmentPeriod || 5,
        suburb: req.body.suburb,
        postcode: req.body.postcode,
        state: req.body.state,
      };

      const calculations = calculateDeal(data);
      
      const aiResult = await analyzeAsset("real_estate", {
        price: data.propertyPrice,
        location: data.location,
        propertyType: data.propertyType,
        units: data.numberOfUnits,
        weeklyRent: data.rentPerUnitPerWeek,
        expensesPercent: data.expensesPercent,
        growthPercent: data.expectedGrowthPercent,
        period: data.investmentPeriod,
        grossYield: calculations.grossYield,
        netYield: calculations.netYield,
        cashFlow: calculations.netAnnualCashFlow,
        suburb: data.suburb,
      });

      const locationScore = calculateLocationScore({
        suburb: data.suburb,
        state: data.state,
      });

      res.json({
        input: data,
        calculations,
        aiAnalysis: {
          verdict: aiResult.verdict,
          riskLevel: aiResult.riskLevel,
          recommendation: aiResult.recommendation,
          bulletPoints: aiResult.strengths.concat(aiResult.weaknesses).slice(0, 5),
          dealLensScore: aiResult.scores.overall,
          scores: aiResult.scores,
          summary: aiResult.summary,
          strengths: aiResult.strengths,
          weaknesses: aiResult.weaknesses,
          risks: aiResult.risks,
          sensitivity: aiResult.sensitivity,
          confidenceLevel: aiResult.confidenceLevel,
          locationScore,
        },
      });
    } catch (error) {
      console.error("Analysis error:", error);
      res.status(500).json({ error: "Failed to analyze deal. Please try again." });
    }
  });

  app.post("/api/analyze/stock", async (req: Request, res: Response) => {
    try {
      const { ticker, companyName, currentPrice, peRatio, dividendYield, marketCap, sector, fiftyTwoWeekHigh, fiftyTwoWeekLow } = req.body;

      if (!ticker || !currentPrice) {
        return res.status(400).json({ error: "Ticker and current price are required" });
      }

      const aiResult = await analyzeAsset("stock", {
        ticker,
        companyName: companyName || ticker,
        currentPrice,
        peRatio,
        dividendYield,
        marketCap,
        sector,
        fiftyTwoWeekHigh,
        fiftyTwoWeekLow,
      });

      res.json({
        input: { ticker, companyName, currentPrice, peRatio, dividendYield, marketCap, sector },
        aiAnalysis: {
          verdict: aiResult.verdict,
          riskLevel: aiResult.riskLevel,
          recommendation: aiResult.recommendation,
          dealLensScore: aiResult.scores.overall,
          scores: aiResult.scores,
          summary: aiResult.summary,
          strengths: aiResult.strengths,
          weaknesses: aiResult.weaknesses,
          risks: aiResult.risks,
          confidenceLevel: aiResult.confidenceLevel,
        },
      });
    } catch (error) {
      console.error("Stock analysis error:", error);
      res.status(500).json({ error: "Failed to analyze stock" });
    }
  });

  app.post("/api/analyze/crypto", async (req: Request, res: Response) => {
    try {
      const { symbol, name, currentPrice, marketCap, volume24h, priceChange24h, priceChange7d, allTimeHigh } = req.body;

      if (!symbol || !currentPrice) {
        return res.status(400).json({ error: "Symbol and current price are required" });
      }

      const aiResult = await analyzeAsset("crypto", {
        symbol,
        name: name || symbol,
        currentPrice,
        marketCap,
        volume24h,
        priceChange24h,
        priceChange7d,
        allTimeHigh,
      });

      res.json({
        input: { symbol, name, currentPrice, marketCap, volume24h, priceChange24h, priceChange7d },
        aiAnalysis: {
          verdict: aiResult.verdict,
          riskLevel: aiResult.riskLevel,
          recommendation: aiResult.recommendation,
          dealLensScore: aiResult.scores.overall,
          scores: aiResult.scores,
          summary: aiResult.summary,
          strengths: aiResult.strengths,
          weaknesses: aiResult.weaknesses,
          risks: aiResult.risks,
          confidenceLevel: aiResult.confidenceLevel,
        },
      });
    } catch (error) {
      console.error("Crypto analysis error:", error);
      res.status(500).json({ error: "Failed to analyze crypto" });
    }
  });

  app.post("/api/analyze/commodity", async (req: Request, res: Response) => {
    try {
      const { name, type, currentPrice, unit, priceChange30d, priceChange1y } = req.body;

      if (!name || !currentPrice) {
        return res.status(400).json({ error: "Name and current price are required" });
      }

      const aiResult = await analyzeAsset("commodity", {
        name,
        type: type || "precious_metal",
        currentPrice,
        unit: unit || "oz",
        priceChange30d,
        priceChange1y,
      });

      res.json({
        input: { name, type, currentPrice, unit, priceChange30d, priceChange1y },
        aiAnalysis: {
          verdict: aiResult.verdict,
          riskLevel: aiResult.riskLevel,
          recommendation: aiResult.recommendation,
          dealLensScore: aiResult.scores.overall,
          scores: aiResult.scores,
          summary: aiResult.summary,
          strengths: aiResult.strengths,
          weaknesses: aiResult.weaknesses,
          risks: aiResult.risks,
          confidenceLevel: aiResult.confidenceLevel,
        },
      });
    } catch (error) {
      console.error("Commodity analysis error:", error);
      res.status(500).json({ error: "Failed to analyze commodity" });
    }
  });

  app.post("/api/analyses", authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const count = await getAnalysisCount(user.id);
      
      if (count >= 50) {
        return res.status(400).json({ error: "Maximum 50 saved analyses reached. Please delete some to save more." });
      }

      const { input, calculations, aiAnalysis } = req.body;
      const shareToken = generateShareToken();
      
      const analysis = await saveAnalysis({
        userId: user.id,
        assetType: "real_estate",
        assetName: input.location,
        propertyPrice: input.propertyPrice,
        location: input.location,
        propertyType: input.propertyType,
        numberOfUnits: input.numberOfUnits,
        rentPerUnitPerWeek: input.rentPerUnitPerWeek,
        expensesPercent: input.expensesPercent,
        expectedGrowthPercent: input.expectedGrowthPercent,
        investmentPeriod: input.investmentPeriod,
        annualRentalIncome: calculations.annualRentalIncome,
        annualExpenses: calculations.annualExpenses,
        netAnnualCashFlow: calculations.netAnnualCashFlow,
        futureValue: calculations.futureValue,
        capitalGain: calculations.capitalGain,
        cashOnCashROI: calculations.cashOnCashROI,
        grossYield: calculations.grossYield,
        netYield: calculations.netYield,
        dealLensScore: aiAnalysis.dealLensScore || aiAnalysis.scores?.overall || 0,
        riskScore: aiAnalysis.scores?.risk || 50,
        yieldScore: aiAnalysis.scores?.yield || 50,
        growthScore: aiAnalysis.scores?.growth || 50,
        liquidityScore: aiAnalysis.scores?.liquidity || 30,
        verdict: aiAnalysis.verdict,
        riskLevel: aiAnalysis.riskLevel,
        bulletPoints: JSON.stringify(aiAnalysis.bulletPoints),
        recommendation: aiAnalysis.recommendation,
        strengths: JSON.stringify(aiAnalysis.strengths || []),
        weaknesses: JSON.stringify(aiAnalysis.weaknesses || []),
        risks: JSON.stringify(aiAnalysis.risks || []),
        confidenceLevel: aiAnalysis.confidenceLevel || 0.8,
        suburb: input.suburb,
        postcode: input.postcode,
        state: input.state,
        locationScore: aiAnalysis.locationScore || 50,
        shareToken,
      });

      await updateUserStats(user.id);
      await updateUserBadges(user.id);
      
      res.status(201).json(analysis);
    } catch (error) {
      console.error("Save analysis error:", error);
      res.status(500).json({ error: "Failed to save analysis" });
    }
  });

  app.get("/api/analyses", authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const analyses = await getUserAnalyses(user.id);
      res.json(analyses);
    } catch (error) {
      console.error("Get analyses error:", error);
      res.status(500).json({ error: "Failed to get analyses" });
    }
  });

  app.delete("/api/analyses/:id", authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const id = parseInt(req.params.id as string);
      
      const deleted = await deleteAnalysis(id, user.id);
      if (!deleted) {
        return res.status(404).json({ error: "Analysis not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Delete analysis error:", error);
      res.status(500).json({ error: "Failed to delete analysis" });
    }
  });

  app.get("/api/share/:token", async (req: Request, res: Response) => {
    try {
      const token = req.params.token as string;
      const analysis = await getAnalysisByShareToken(token);
      
      if (!analysis) {
        return res.status(404).json({ error: "Analysis not found" });
      }
      
      res.json({
        location: analysis.location,
        propertyPrice: analysis.propertyPrice,
        propertyType: analysis.propertyType,
        verdict: analysis.verdict,
        riskLevel: analysis.riskLevel,
        recommendation: analysis.recommendation,
        grossYield: analysis.grossYield,
        netYield: analysis.netYield,
        cashOnCashROI: analysis.cashOnCashROI,
        capitalGain: analysis.capitalGain,
        netAnnualCashFlow: analysis.netAnnualCashFlow,
        dealLensScore: analysis.dealLensScore,
        bulletPoints: JSON.parse(analysis.bulletPoints),
        strengths: JSON.parse(analysis.strengths || "[]"),
        weaknesses: JSON.parse(analysis.weaknesses || "[]"),
      });
    } catch (error) {
      console.error("Share fetch error:", error);
      res.status(500).json({ error: "Failed to fetch shared analysis" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

async function getAnalysisByShareToken(token: string) {
  const { db } = await import("./db");
  const { savedAnalyses } = await import("../shared/schema");
  const { eq } = await import("drizzle-orm");
  
  const [analysis] = await db.select()
    .from(savedAnalyses)
    .where(eq(savedAnalyses.shareToken, token));
  
  return analysis || null;
}
