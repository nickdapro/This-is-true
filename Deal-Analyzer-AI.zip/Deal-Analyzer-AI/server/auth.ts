import { db } from "./db";
import { users, sessions, passwordResetTokens } from "../shared/schema";
import { eq, and, gt, isNull } from "drizzle-orm";
import crypto from "crypto";

function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password).digest("hex");
}

function generateSessionId(): string {
  return crypto.randomBytes(32).toString("hex");
}

function generateResetToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

export function validateEmail(email: string): ValidationResult {
  const errors: string[] = [];
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  if (!email || !email.trim()) {
    errors.push("Email is required");
  } else if (!emailRegex.test(email.trim())) {
    errors.push("Please enter a valid email address");
  } else if (email.length > 255) {
    errors.push("Email is too long");
  }
  
  return { isValid: errors.length === 0, errors };
}

export function validatePassword(password: string): ValidationResult {
  const errors: string[] = [];
  
  if (!password) {
    errors.push("Password is required");
  } else {
    if (password.length < 8) {
      errors.push("Password must be at least 8 characters");
    }
    if (password.length > 128) {
      errors.push("Password is too long");
    }
    if (!/[A-Z]/.test(password)) {
      errors.push("Password must contain at least one uppercase letter");
    }
    if (!/[a-z]/.test(password)) {
      errors.push("Password must contain at least one lowercase letter");
    }
    if (!/[0-9]/.test(password)) {
      errors.push("Password must contain at least one number");
    }
  }
  
  return { isValid: errors.length === 0, errors };
}

export function validateName(name: string): ValidationResult {
  const errors: string[] = [];
  
  if (!name || !name.trim()) {
    errors.push("Name is required");
  } else if (name.trim().length < 2) {
    errors.push("Name must be at least 2 characters");
  } else if (name.trim().length > 100) {
    errors.push("Name is too long");
  }
  
  return { isValid: errors.length === 0, errors };
}

export function getPasswordStrength(password: string): { score: number; label: string; color: string } {
  let score = 0;
  
  if (password.length >= 8) score += 1;
  if (password.length >= 12) score += 1;
  if (/[A-Z]/.test(password)) score += 1;
  if (/[a-z]/.test(password)) score += 1;
  if (/[0-9]/.test(password)) score += 1;
  if (/[^A-Za-z0-9]/.test(password)) score += 1;
  
  if (score <= 2) return { score, label: "Weak", color: "#EF4444" };
  if (score <= 4) return { score, label: "Fair", color: "#F59E0B" };
  return { score, label: "Strong", color: "#10B981" };
}

export async function createUser(email: string, password: string, name: string) {
  const emailValidation = validateEmail(email);
  if (!emailValidation.isValid) {
    throw new Error(emailValidation.errors[0]);
  }
  
  const passwordValidation = validatePassword(password);
  if (!passwordValidation.isValid) {
    throw new Error(passwordValidation.errors[0]);
  }
  
  const nameValidation = validateName(name);
  if (!nameValidation.isValid) {
    throw new Error(nameValidation.errors[0]);
  }
  
  const existing = await getUserByEmail(email);
  if (existing) {
    throw new Error("An account with this email already exists");
  }
  
  const hashedPassword = hashPassword(password);
  const [user] = await db.insert(users).values({
    email: email.toLowerCase().trim(),
    password: hashedPassword,
    name: name.trim(),
  }).returning();
  return user;
}

export async function createUserWithGoogle(email: string, name: string, googleId: string, avatarUrl?: string) {
  const existing = await getUserByEmail(email);
  if (existing) {
    if (existing.googleId === googleId) {
      return existing;
    }
    if (!existing.googleId) {
      const [updated] = await db.update(users)
        .set({ googleId, avatarUrl: avatarUrl || existing.avatarUrl })
        .where(eq(users.id, existing.id))
        .returning();
      return updated;
    }
    throw new Error("An account with this email already exists");
  }
  
  const [user] = await db.insert(users).values({
    email: email.toLowerCase().trim(),
    name: name.trim(),
    googleId,
    avatarUrl,
    password: null,
  }).returning();
  return user;
}

export async function validateUser(email: string, password: string) {
  const emailValidation = validateEmail(email);
  if (!emailValidation.isValid) {
    return null;
  }
  
  const hashedPassword = hashPassword(password);
  const [user] = await db.select().from(users).where(eq(users.email, email.toLowerCase().trim()));
  
  if (!user) {
    return null;
  }
  
  if (!user.password) {
    throw new Error("This account uses Google sign-in. Please sign in with Google.");
  }
  
  if (user.password !== hashedPassword) {
    return null;
  }
  
  return user;
}

export async function getUserById(id: number) {
  const [user] = await db.select().from(users).where(eq(users.id, id));
  return user || null;
}

export async function getUserByEmail(email: string) {
  const [user] = await db.select().from(users).where(eq(users.email, email.toLowerCase().trim()));
  return user || null;
}

export async function getUserByGoogleId(googleId: string) {
  const [user] = await db.select().from(users).where(eq(users.googleId, googleId));
  return user || null;
}

export async function createSession(userId: number, rememberMe: boolean = false) {
  const sessionId = generateSessionId();
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + (rememberMe ? 30 : 1));
  
  await db.insert(sessions).values({
    id: sessionId,
    userId,
    expiresAt,
  });
  
  return { sessionId, expiresAt };
}

export async function validateSession(sessionId: string) {
  const [session] = await db.select().from(sessions).where(eq(sessions.id, sessionId));
  if (!session) {
    return null;
  }
  if (new Date() > session.expiresAt) {
    await db.delete(sessions).where(eq(sessions.id, sessionId));
    return null;
  }
  const user = await getUserById(session.userId);
  return user;
}

export async function deleteSession(sessionId: string) {
  await db.delete(sessions).where(eq(sessions.id, sessionId));
}

export async function createPasswordResetToken(email: string): Promise<string | null> {
  const user = await getUserByEmail(email);
  if (!user) {
    return null;
  }
  
  if (!user.password && user.googleId) {
    throw new Error("This account uses Google sign-in. Password reset is not available.");
  }
  
  await db.delete(passwordResetTokens).where(eq(passwordResetTokens.userId, user.id));
  
  const token = generateResetToken();
  const expiresAt = new Date();
  expiresAt.setHours(expiresAt.getHours() + 1);
  
  await db.insert(passwordResetTokens).values({
    userId: user.id,
    token,
    expiresAt,
  });
  
  return token;
}

export async function validateResetToken(token: string): Promise<number | null> {
  const [resetToken] = await db.select()
    .from(passwordResetTokens)
    .where(
      and(
        eq(passwordResetTokens.token, token),
        gt(passwordResetTokens.expiresAt, new Date()),
        isNull(passwordResetTokens.usedAt)
      )
    );
  
  if (!resetToken) {
    return null;
  }
  
  return resetToken.userId;
}

export async function resetPassword(token: string, newPassword: string): Promise<boolean> {
  const passwordValidation = validatePassword(newPassword);
  if (!passwordValidation.isValid) {
    throw new Error(passwordValidation.errors[0]);
  }
  
  const userId = await validateResetToken(token);
  if (!userId) {
    throw new Error("Invalid or expired reset link. Please request a new password reset.");
  }
  
  const hashedPassword = hashPassword(newPassword);
  
  await db.update(users)
    .set({ password: hashedPassword })
    .where(eq(users.id, userId));
  
  await db.update(passwordResetTokens)
    .set({ usedAt: new Date() })
    .where(eq(passwordResetTokens.token, token));
  
  await db.delete(sessions).where(eq(sessions.userId, userId));
  
  return true;
}

export async function updateUser(userId: number, data: { name?: string; email?: string }) {
  if (data.email) {
    const emailValidation = validateEmail(data.email);
    if (!emailValidation.isValid) {
      throw new Error(emailValidation.errors[0]);
    }
    
    const existing = await getUserByEmail(data.email);
    if (existing && existing.id !== userId) {
      throw new Error("This email is already in use");
    }
  }
  
  if (data.name) {
    const nameValidation = validateName(data.name);
    if (!nameValidation.isValid) {
      throw new Error(nameValidation.errors[0]);
    }
  }
  
  const updateData: Record<string, string> = {};
  if (data.name) updateData.name = data.name.trim();
  if (data.email) updateData.email = data.email.toLowerCase().trim();
  
  const [user] = await db.update(users)
    .set(updateData)
    .where(eq(users.id, userId))
    .returning();
  return user;
}

export async function updateUserStats(userId: number) {
  const user = await getUserById(userId);
  if (!user) return;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const lastAnalysisDate = user.lastAnalysisDate ? new Date(user.lastAnalysisDate) : null;
  let newStreak = user.currentStreak || 0;

  if (lastAnalysisDate) {
    lastAnalysisDate.setHours(0, 0, 0, 0);
    const diffDays = Math.floor((today.getTime() - lastAnalysisDate.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) {
      newStreak += 1;
    } else if (diffDays > 1) {
      newStreak = 1;
    }
  } else {
    newStreak = 1;
  }

  await db.update(users)
    .set({
      propertiesAnalyzed: (user.propertiesAnalyzed || 0) + 1,
      currentStreak: newStreak,
      lastAnalysisDate: new Date(),
    })
    .where(eq(users.id, userId));
}

export async function updateUserBadges(userId: number) {
  const user = await getUserById(userId);
  if (!user) return;

  const currentBadges = JSON.parse(user.badges || "[]") as string[];
  const newBadges = [...currentBadges];
  const analyzed = user.propertiesAnalyzed || 0;
  const streak = user.currentStreak || 0;

  const badgeRules = [
    { id: "first_analysis", condition: analyzed >= 1, name: "First Analysis" },
    { id: "five_properties", condition: analyzed >= 5, name: "Property Explorer" },
    { id: "ten_properties", condition: analyzed >= 10, name: "Deal Hunter" },
    { id: "twenty_five_properties", condition: analyzed >= 25, name: "Market Expert" },
    { id: "fifty_properties", condition: analyzed >= 50, name: "Investment Pro" },
    { id: "three_day_streak", condition: streak >= 3, name: "Consistent Analyst" },
    { id: "seven_day_streak", condition: streak >= 7, name: "Weekly Warrior" },
    { id: "fourteen_day_streak", condition: streak >= 14, name: "Dedicated Investor" },
  ];

  let hasNewBadge = false;
  for (const rule of badgeRules) {
    if (rule.condition && !currentBadges.includes(rule.id)) {
      newBadges.push(rule.id);
      hasNewBadge = true;
    }
  }

  if (hasNewBadge) {
    const healthLevel = Math.min(100, Math.floor(newBadges.length * 12.5));
    await db.update(users)
      .set({
        badges: JSON.stringify(newBadges),
        portfolioHealthLevel: healthLevel,
      })
      .where(eq(users.id, userId));
  }
}
