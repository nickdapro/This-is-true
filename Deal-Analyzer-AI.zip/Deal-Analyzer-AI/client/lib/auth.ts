import AsyncStorage from "@react-native-async-storage/async-storage";
import { getApiUrl } from "./query-client";

const SESSION_KEY = "deallens_session";
const USER_KEY = "deallens_user";

export interface User {
  id: number;
  email: string;
  name: string;
  avatarUrl?: string;
}

export interface AuthState {
  user: User | null;
  sessionId: string | null;
  isLoading: boolean;
}

export interface PasswordStrength {
  score: number;
  label: string;
  color: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  strength?: PasswordStrength;
}

export async function getStoredSession(): Promise<{ user: User | null; sessionId: string | null }> {
  try {
    const [sessionId, userJson] = await Promise.all([
      AsyncStorage.getItem(SESSION_KEY),
      AsyncStorage.getItem(USER_KEY),
    ]);
    
    if (!sessionId || !userJson) {
      return { user: null, sessionId: null };
    }
    
    const user = JSON.parse(userJson) as User;
    return { user, sessionId };
  } catch {
    return { user: null, sessionId: null };
  }
}

export async function storeSession(sessionId: string, user: User): Promise<void> {
  await Promise.all([
    AsyncStorage.setItem(SESSION_KEY, sessionId),
    AsyncStorage.setItem(USER_KEY, JSON.stringify(user)),
  ]);
}

export async function clearSession(): Promise<void> {
  await Promise.all([
    AsyncStorage.removeItem(SESSION_KEY),
    AsyncStorage.removeItem(USER_KEY),
  ]);
}

export function validateEmail(email: string): { isValid: boolean; error?: string } {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  if (!email || !email.trim()) {
    return { isValid: false, error: "Email is required" };
  }
  if (!emailRegex.test(email.trim())) {
    return { isValid: false, error: "Please enter a valid email" };
  }
  if (email.length > 255) {
    return { isValid: false, error: "Email is too long" };
  }
  
  return { isValid: true };
}

export function validatePassword(password: string): ValidationResult {
  const errors: string[] = [];
  
  if (!password) {
    errors.push("Password is required");
  } else {
    if (password.length < 8) {
      errors.push("At least 8 characters");
    }
    if (!/[A-Z]/.test(password)) {
      errors.push("One uppercase letter");
    }
    if (!/[a-z]/.test(password)) {
      errors.push("One lowercase letter");
    }
    if (!/[0-9]/.test(password)) {
      errors.push("One number");
    }
  }
  
  const strength = getPasswordStrength(password);
  
  return { isValid: errors.length === 0, errors, strength };
}

export function getPasswordStrength(password: string): PasswordStrength {
  let score = 0;
  
  if (password.length >= 8) score += 1;
  if (password.length >= 12) score += 1;
  if (/[A-Z]/.test(password)) score += 1;
  if (/[a-z]/.test(password)) score += 1;
  if (/[0-9]/.test(password)) score += 1;
  if (/[^A-Za-z0-9]/.test(password)) score += 1;
  
  if (score <= 2) return { score, label: "Weak", color: "#EF4444" };
  if (score <= 4) return { score, label: "Fair", color: "#F59E0B" };
  return { score, label: "Strong", color: "#10B981" };
}

export function validateName(name: string): { isValid: boolean; error?: string } {
  if (!name || !name.trim()) {
    return { isValid: false, error: "Name is required" };
  }
  if (name.trim().length < 2) {
    return { isValid: false, error: "Name must be at least 2 characters" };
  }
  if (name.trim().length > 100) {
    return { isValid: false, error: "Name is too long" };
  }
  
  return { isValid: true };
}

export async function signup(email: string, password: string, name: string): Promise<{ user: User; sessionId: string }> {
  const baseUrl = getApiUrl();
  const response = await fetch(new URL("/api/auth/signup", baseUrl), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password, name }),
  });
  
  if (!response.ok) {
    const data = await response.json();
    throw new Error(data.error || "Signup failed");
  }
  
  const data = await response.json();
  await storeSession(data.sessionId, data.user);
  return { user: data.user, sessionId: data.sessionId };
}

export async function login(email: string, password: string, rememberMe: boolean = false): Promise<{ user: User; sessionId: string }> {
  const baseUrl = getApiUrl();
  const response = await fetch(new URL("/api/auth/login", baseUrl), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password, rememberMe }),
  });
  
  if (!response.ok) {
    const data = await response.json();
    throw new Error(data.error || "Login failed");
  }
  
  const data = await response.json();
  await storeSession(data.sessionId, data.user);
  return { user: data.user, sessionId: data.sessionId };
}

export async function loginWithGoogle(email: string, name: string, googleId: string, avatarUrl?: string, rememberMe: boolean = false): Promise<{ user: User; sessionId: string }> {
  const baseUrl = getApiUrl();
  const response = await fetch(new URL("/api/auth/google", baseUrl), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, name, googleId, avatarUrl, rememberMe }),
  });
  
  if (!response.ok) {
    const data = await response.json();
    throw new Error(data.error || "Google sign-in failed");
  }
  
  const data = await response.json();
  await storeSession(data.sessionId, data.user);
  return { user: data.user, sessionId: data.sessionId };
}

export async function logout(sessionId: string): Promise<void> {
  const baseUrl = getApiUrl();
  try {
    await fetch(new URL("/api/auth/logout", baseUrl), {
      method: "POST",
      headers: { Authorization: `Bearer ${sessionId}` },
    });
  } catch {
  }
  await clearSession();
}

export async function validateStoredSession(): Promise<{ user: User; sessionId: string } | null> {
  const { sessionId } = await getStoredSession();
  if (!sessionId) return null;
  
  const baseUrl = getApiUrl();
  try {
    const response = await fetch(new URL("/api/auth/me", baseUrl), {
      headers: { Authorization: `Bearer ${sessionId}` },
    });
    
    if (!response.ok) {
      await clearSession();
      return null;
    }
    
    const user = await response.json();
    await storeSession(sessionId, user);
    return { user, sessionId };
  } catch {
    return null;
  }
}

export async function requestPasswordReset(email: string): Promise<{ success: boolean; token?: string }> {
  const baseUrl = getApiUrl();
  const response = await fetch(new URL("/api/auth/forgot-password", baseUrl), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email }),
  });
  
  if (!response.ok) {
    const data = await response.json();
    throw new Error(data.error || "Failed to send reset email");
  }
  
  const data = await response.json();
  return { success: true, token: data.token };
}

export async function verifyResetToken(token: string): Promise<boolean> {
  const baseUrl = getApiUrl();
  const response = await fetch(new URL("/api/auth/verify-reset-token", baseUrl), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ token }),
  });
  
  if (!response.ok) {
    return false;
  }
  
  const data = await response.json();
  return data.valid === true;
}

export async function resetPassword(token: string, password: string): Promise<void> {
  const baseUrl = getApiUrl();
  const response = await fetch(new URL("/api/auth/reset-password", baseUrl), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ token, password }),
  });
  
  if (!response.ok) {
    const data = await response.json();
    throw new Error(data.error || "Failed to reset password");
  }
}
