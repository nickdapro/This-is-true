import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { Alert, Platform } from "react-native";
import {
  User,
  getStoredSession,
  login as authLogin,
  signup as authSignup,
  logout as authLogout,
  validateStoredSession,
  loginWithGoogle as authLoginWithGoogle,
  requestPasswordReset as authRequestPasswordReset,
  verifyResetToken as authVerifyResetToken,
  resetPassword as authResetPassword,
} from "@/lib/auth";
import AsyncStorage from "@react-native-async-storage/async-storage";

interface AuthContextType {
  user: User | null;
  sessionId: string | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string, rememberMe?: boolean) => Promise<void>;
  signup: (email: string, password: string, name: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
  loginWithGoogle: (email: string, name: string, googleId: string, avatarUrl?: string, rememberMe?: boolean) => Promise<void>;
  requestPasswordReset: (email: string) => Promise<{ token?: string }>;
  verifyResetToken: (token: string) => Promise<boolean>;
  resetPassword: (token: string, password: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadStoredSession();
  }, []);

  const loadStoredSession = async () => {
    try {
      const result = await validateStoredSession();
      if (result) {
        setUser(result.user);
        setSessionId(result.sessionId);
      }
    } catch {
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (email: string, password: string, rememberMe?: boolean) => {
    const result = await authLogin(email, password, rememberMe);
    setUser(result.user);
    setSessionId(result.sessionId);
  };

  const signup = async (email: string, password: string, name: string) => {
    const result = await authSignup(email, password, name);
    setUser(result.user);
    setSessionId(result.sessionId);
  };

  const logout = async () => {
    if (sessionId) {
      await authLogout(sessionId);
    }
    setUser(null);
    setSessionId(null);
  };

  const refreshUser = async () => {
    const result = await validateStoredSession();
    if (result) {
      setUser(result.user);
      setSessionId(result.sessionId);
    }
  };

  const loginWithGoogle = async (email: string, name: string, googleId: string, avatarUrl?: string, rememberMe?: boolean) => {
    const result = await authLoginWithGoogle(email, name, googleId, avatarUrl, rememberMe);
    setUser(result.user);
    setSessionId(result.sessionId);
  };

  const requestPasswordReset = async (email: string): Promise<{ token?: string }> => {
    const result = await authRequestPasswordReset(email);
    return { token: result.token };
  };

  const verifyResetToken = async (token: string): Promise<boolean> => {
    return authVerifyResetToken(token);
  };

  const resetPassword = async (token: string, password: string): Promise<void> => {
    await authResetPassword(token, password);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        sessionId,
        isLoading,
        isAuthenticated: !!user,
        login,
        signup,
        logout,
        refreshUser,
        loginWithGoogle,
        requestPasswordReset,
        verifyResetToken,
        resetPassword,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
