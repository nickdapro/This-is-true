import { Platform } from "react-native";

const primaryGold = "#D4AF37";
const primaryGoldDark = "#E8C547";
const accentBlue = "#2563EB";
const accentBlueDark = "#3B82F6";
const accentGreen = "#10B981";

export const Colors = {
  light: {
    text: "#1A1A2E",
    textSecondary: "#6B7280",
    buttonText: "#FFFFFF",
    tabIconDefault: "#6B7280",
    tabIconSelected: primaryGold,
    link: accentBlue,
    primary: primaryGold,
    primaryLight: "#F5EED6",
    backgroundRoot: "#FEFEF9",
    backgroundDefault: "#FFFFFF",
    backgroundSecondary: "#F9FAFB",
    backgroundTertiary: "#F3F4F6",
    border: "#E5E7EB",
    success: accentGreen,
    successBackground: "#ECFDF5",
    warning: "#F59E0B",
    warningBackground: "#FEF3C7",
    danger: "#EF4444",
    dangerBackground: "#FEF2F2",
    info: accentBlue,
    infoBackground: "#EFF6FF",
    gradient1: "#D4AF37",
    gradient2: "#F5E6A3",
    chartBlue: "#3B82F6",
    chartGreen: "#10B981",
    chartPurple: "#8B5CF6",
    chartOrange: "#F97316",
    chartPink: "#EC4899",
  },
  dark: {
    text: "#F9FAFB",
    textSecondary: "#9CA3AF",
    buttonText: "#FFFFFF",
    tabIconDefault: "#6B7280",
    tabIconSelected: primaryGoldDark,
    link: accentBlueDark,
    primary: primaryGoldDark,
    primaryLight: "#2D2A1F",
    backgroundRoot: "#0F0F1A",
    backgroundDefault: "#1A1A2E",
    backgroundSecondary: "#252538",
    backgroundTertiary: "#2F2F45",
    border: "#3F3F5C",
    success: accentGreen,
    successBackground: "#064E3B",
    warning: "#F59E0B",
    warningBackground: "#78350F",
    danger: "#EF4444",
    dangerBackground: "#7F1D1D",
    info: accentBlueDark,
    infoBackground: "#1E3A8A",
    gradient1: "#E8C547",
    gradient2: "#D4AF37",
    chartBlue: "#60A5FA",
    chartGreen: "#34D399",
    chartPurple: "#A78BFA",
    chartOrange: "#FB923C",
    chartPink: "#F472B6",
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  "2xl": 48,
  inputHeight: 52,
  buttonHeight: 56,
};

export const BorderRadius = {
  xs: 6,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  "2xl": 24,
  full: 9999,
};

export const Typography = {
  h1: {
    fontSize: 36,
    lineHeight: 44,
    fontWeight: "700" as const,
    letterSpacing: -0.5,
  },
  h2: {
    fontSize: 30,
    lineHeight: 38,
    fontWeight: "700" as const,
    letterSpacing: -0.3,
  },
  h3: {
    fontSize: 24,
    lineHeight: 32,
    fontWeight: "600" as const,
  },
  h4: {
    fontSize: 20,
    lineHeight: 28,
    fontWeight: "600" as const,
  },
  body: {
    fontSize: 16,
    lineHeight: 24,
    fontWeight: "400" as const,
  },
  small: {
    fontSize: 14,
    lineHeight: 20,
    fontWeight: "400" as const,
  },
  label: {
    fontSize: 14,
    lineHeight: 20,
    fontWeight: "500" as const,
  },
  metric: {
    fontSize: 36,
    lineHeight: 44,
    fontWeight: "700" as const,
    letterSpacing: -0.5,
  },
  metricLabel: {
    fontSize: 11,
    lineHeight: 14,
    fontWeight: "600" as const,
    letterSpacing: 0.8,
    textTransform: "uppercase" as const,
  },
  link: {
    fontSize: 16,
    lineHeight: 24,
    fontWeight: "500" as const,
  },
};

export const Shadows = {
  sm: {
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  md: {
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  lg: {
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.12,
    shadowRadius: 16,
    elevation: 5,
  },
  gold: {
    shadowColor: "#D4AF37",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    elevation: 4,
  },
};

export const Fonts = Platform.select({
  ios: {
    sans: "system-ui",
    serif: "Georgia",
    rounded: "ui-rounded",
    mono: "ui-monospace",
  },
  default: {
    sans: "normal",
    serif: "serif",
    rounded: "normal",
    mono: "monospace",
  },
  web: {
    sans: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
    serif: "Georgia, 'Times New Roman', serif",
    rounded: "'SF Pro Rounded', 'Helvetica Neue', sans-serif",
    mono: "SFMono-Regular, Menlo, Monaco, Consolas, monospace",
  },
});
