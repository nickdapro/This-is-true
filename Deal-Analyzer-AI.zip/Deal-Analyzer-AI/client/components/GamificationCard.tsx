import React from "react";
import { View, StyleSheet } from "react-native";
import { Feather } from "@expo/vector-icons";
import Animated, { FadeIn } from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";

interface GamificationCardProps {
  propertiesAnalyzed: number;
  currentStreak: number;
}

export function GamificationCard({ propertiesAnalyzed, currentStreak }: GamificationCardProps) {
  const { theme, isDark } = useTheme();
  const colors = Colors[isDark ? "dark" : "light"];

  const achievements = [
    { icon: "target", label: "First Analysis", unlocked: propertiesAnalyzed >= 1 },
    { icon: "trending-up", label: "5 Properties", unlocked: propertiesAnalyzed >= 5 },
    { icon: "award", label: "10 Properties", unlocked: propertiesAnalyzed >= 10 },
    { icon: "star", label: "3-Day Streak", unlocked: currentStreak >= 3 },
    { icon: "zap", label: "7-Day Streak", unlocked: currentStreak >= 7 },
  ];

  const unlockedCount = achievements.filter((a) => a.unlocked).length;

  return (
    <Animated.View
      entering={FadeIn.duration(400)}
      style={[styles.container, { backgroundColor: theme.backgroundDefault, borderColor: theme.border }]}
    >
      <View style={styles.header}>
        <ThemedText style={styles.title}>Your Progress</ThemedText>
        <View style={[styles.badge, { backgroundColor: colors.primaryLight }]}>
          <Feather name="award" size={14} color={colors.primary} />
          <ThemedText style={[styles.badgeText, { color: colors.primary }]}>
            {unlockedCount}/{achievements.length}
          </ThemedText>
        </View>
      </View>

      <View style={styles.statsRow}>
        <View style={styles.statBox}>
          <View style={[styles.statIcon, { backgroundColor: colors.infoBackground }]}>
            <Feather name="home" size={18} color={colors.info} />
          </View>
          <ThemedText style={styles.statValue}>{propertiesAnalyzed}</ThemedText>
          <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>
            Properties
          </ThemedText>
        </View>

        <View style={styles.statBox}>
          <View style={[styles.statIcon, { backgroundColor: colors.warningBackground }]}>
            <Feather name="zap" size={18} color={colors.warning} />
          </View>
          <ThemedText style={styles.statValue}>{currentStreak}</ThemedText>
          <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>
            Day Streak
          </ThemedText>
        </View>
      </View>

      <View style={styles.achievementsRow}>
        {achievements.map((achievement, index) => (
          <View
            key={index}
            style={[
              styles.achievementBadge,
              {
                backgroundColor: achievement.unlocked ? colors.successBackground : theme.backgroundTertiary,
                opacity: achievement.unlocked ? 1 : 0.5,
              },
            ]}
          >
            <Feather
              name={achievement.icon as any}
              size={16}
              color={achievement.unlocked ? colors.success : theme.textSecondary}
            />
          </View>
        ))}
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    padding: Spacing.md,
    marginBottom: Spacing.lg,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  title: {
    fontSize: 16,
    fontWeight: "600",
  },
  badge: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
    gap: 4,
  },
  badgeText: {
    fontSize: 12,
    fontWeight: "600",
  },
  statsRow: {
    flexDirection: "row",
    gap: Spacing.md,
    marginBottom: Spacing.md,
  },
  statBox: {
    flex: 1,
    alignItems: "center",
    gap: Spacing.xs,
  },
  statIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  statValue: {
    fontSize: 24,
    fontWeight: "700",
  },
  statLabel: {
    fontSize: 11,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  achievementsRow: {
    flexDirection: "row",
    justifyContent: "center",
    gap: Spacing.sm,
  },
  achievementBadge: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
});
