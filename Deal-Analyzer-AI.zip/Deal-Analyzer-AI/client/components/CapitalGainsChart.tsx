import React from "react";
import { View, StyleSheet, Dimensions } from "react-native";
import Svg, { Rect, Text as SvgText, Defs, LinearGradient, Stop, Line } from "react-native-svg";
import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";

interface CapitalGainsChartProps {
  propertyPrice: number;
  futureValue: number;
  investmentPeriod: number;
  growthPercent: number;
}

export function CapitalGainsChart({ propertyPrice, futureValue, investmentPeriod, growthPercent }: CapitalGainsChartProps) {
  const { theme, isDark } = useTheme();
  const colors = Colors[isDark ? "dark" : "light"];
  
  const width = Dimensions.get("window").width - Spacing.lg * 2 - Spacing.md * 2;
  const height = 200;
  const padding = { top: 20, right: 20, bottom: 40, left: 60 };
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;

  const values: number[] = [];
  for (let i = 0; i <= investmentPeriod; i++) {
    values.push(propertyPrice * Math.pow(1 + growthPercent / 100, i));
  }

  const maxValue = Math.max(...values);
  const barCount = values.length;
  const barWidth = (chartWidth / barCount) * 0.7;
  const barGap = (chartWidth / barCount) * 0.3;

  const getBarHeight = (value: number) => (value / maxValue) * chartHeight;
  const getX = (index: number) => padding.left + (index * chartWidth) / barCount + barGap / 2;

  const formatValue = (value: number) => {
    if (value >= 1000000) {
      return `$${(value / 1000000).toFixed(1)}M`;
    }
    if (value >= 1000) {
      return `$${(value / 1000).toFixed(0)}K`;
    }
    return `$${value.toFixed(0)}`;
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundDefault, borderColor: theme.border }]}>
      <ThemedText style={styles.title}>Property Value Growth</ThemedText>
      <Svg width={width} height={height}>
        <Defs>
          <LinearGradient id="barGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <Stop offset="0%" stopColor={colors.primary} />
            <Stop offset="100%" stopColor={colors.chartOrange} />
          </LinearGradient>
        </Defs>

        <Line
          x1={padding.left}
          y1={height - padding.bottom}
          x2={width - padding.right}
          y2={height - padding.bottom}
          stroke={theme.border}
          strokeWidth={1}
        />

        {values.map((value, index) => {
          const barHeight = getBarHeight(value);
          const x = getX(index);
          const y = height - padding.bottom - barHeight;
          const isFirst = index === 0;
          const isLast = index === values.length - 1;
          
          return (
            <React.Fragment key={index}>
              <Rect
                x={x}
                y={y}
                width={barWidth}
                height={barHeight}
                rx={4}
                fill={isFirst ? theme.textSecondary : isLast ? colors.success : "url(#barGradient)"}
              />
              <SvgText
                x={x + barWidth / 2}
                y={y - 6}
                fontSize={9}
                fill={theme.text}
                textAnchor="middle"
                fontWeight="600"
              >
                {formatValue(value)}
              </SvgText>
              <SvgText
                x={x + barWidth / 2}
                y={height - padding.bottom + 16}
                fontSize={10}
                fill={theme.textSecondary}
                textAnchor="middle"
              >
                {`Yr ${index}`}
              </SvgText>
            </React.Fragment>
          );
        })}
      </Svg>
      <View style={styles.legend}>
        <View style={styles.legendItem}>
          <View style={[styles.legendDot, { backgroundColor: theme.textSecondary }]} />
          <ThemedText style={[styles.legendText, { color: theme.textSecondary }]}>Purchase</ThemedText>
        </View>
        <View style={styles.legendItem}>
          <View style={[styles.legendDot, { backgroundColor: colors.success }]} />
          <ThemedText style={[styles.legendText, { color: theme.textSecondary }]}>Final Value</ThemedText>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    padding: Spacing.md,
    marginBottom: Spacing.md,
  },
  title: {
    fontSize: 16,
    fontWeight: "600",
    marginBottom: Spacing.sm,
  },
  legend: {
    flexDirection: "row",
    justifyContent: "center",
    gap: Spacing.lg,
    marginTop: Spacing.sm,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
  },
  legendDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  legendText: {
    fontSize: 11,
  },
});
