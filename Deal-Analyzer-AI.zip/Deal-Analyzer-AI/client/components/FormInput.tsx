import React from "react";
import { View, TextInput, StyleSheet, TextInputProps } from "react-native";
import { Feather } from "@expo/vector-icons";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";

interface FormInputProps extends TextInputProps {
  label: string;
  prefix?: string;
  suffix?: string;
  error?: string;
}

export function FormInput({
  label,
  prefix,
  suffix,
  error,
  style,
  ...props
}: FormInputProps) {
  const { theme, isDark } = useTheme();

  return (
    <View style={styles.container}>
      <ThemedText style={[styles.label, { color: theme.textSecondary }]}>
        {label}
      </ThemedText>
      <View
        style={[
          styles.inputContainer,
          {
            backgroundColor: theme.backgroundDefault,
            borderColor: error ? Colors.light.danger : theme.border,
          },
        ]}
      >
        {prefix ? (
          <ThemedText style={[styles.affix, { color: theme.textSecondary }]}>
            {prefix}
          </ThemedText>
        ) : null}
        <TextInput
          style={[
            styles.input,
            {
              color: theme.text,
              textAlign: props.keyboardType === "numeric" ? "right" : "left",
            },
            style,
          ]}
          placeholderTextColor={theme.textSecondary}
          {...props}
        />
        {suffix ? (
          <ThemedText style={[styles.affix, { color: theme.textSecondary }]}>
            {suffix}
          </ThemedText>
        ) : null}
      </View>
      {error ? (
        <ThemedText style={styles.errorText}>{error}</ThemedText>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.md,
  },
  label: {
    fontSize: 14,
    fontWeight: "500",
    marginBottom: Spacing.xs,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    height: Spacing.inputHeight,
    borderWidth: 1,
    borderRadius: BorderRadius.xs,
    paddingHorizontal: Spacing.md,
  },
  input: {
    flex: 1,
    fontSize: 16,
    height: "100%",
  },
  affix: {
    fontSize: 16,
    marginHorizontal: Spacing.xs,
  },
  errorText: {
    color: Colors.light.danger,
    fontSize: 12,
    marginTop: Spacing.xs,
  },
});
