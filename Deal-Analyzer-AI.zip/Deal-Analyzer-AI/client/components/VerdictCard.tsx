import React from "react";
import { View, StyleSheet } from "react-native";
import { Feather } from "@expo/vector-icons";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";

interface VerdictCardProps {
  verdict: "Good" | "Neutral" | "Bad";
  riskLevel: "Low" | "Medium" | "High";
}

export function VerdictCard({ verdict, riskLevel }: VerdictCardProps) {
  const { theme, isDark } = useTheme();

  const getVerdictConfig = () => {
    switch (verdict) {
      case "Good":
        return {
          backgroundColor: Colors[isDark ? "dark" : "light"].successBackground,
          textColor: Colors[isDark ? "dark" : "light"].success,
          icon: "check-circle" as const,
        };
      case "Bad":
        return {
          backgroundColor: Colors[isDark ? "dark" : "light"].dangerBackground,
          textColor: Colors[isDark ? "dark" : "light"].danger,
          icon: "x-circle" as const,
        };
      default:
        return {
          backgroundColor: Colors[isDark ? "dark" : "light"].warningBackground,
          textColor: Colors[isDark ? "dark" : "light"].warning,
          icon: "minus-circle" as const,
        };
    }
  };

  const getRiskConfig = () => {
    switch (riskLevel) {
      case "Low":
        return {
          backgroundColor: Colors[isDark ? "dark" : "light"].success,
          textColor: "#FFFFFF",
        };
      case "High":
        return {
          backgroundColor: Colors[isDark ? "dark" : "light"].danger,
          textColor: "#FFFFFF",
        };
      default:
        return {
          backgroundColor: Colors[isDark ? "dark" : "light"].warning,
          textColor: "#FFFFFF",
        };
    }
  };

  const verdictConfig = getVerdictConfig();
  const riskConfig = getRiskConfig();

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: verdictConfig.backgroundColor },
      ]}
    >
      <View style={styles.verdictRow}>
        <Feather
          name={verdictConfig.icon}
          size={32}
          color={verdictConfig.textColor}
        />
        <ThemedText
          style={[styles.verdictText, { color: verdictConfig.textColor }]}
        >
          {verdict} Deal
        </ThemedText>
      </View>
      <View
        style={[styles.riskBadge, { backgroundColor: riskConfig.backgroundColor }]}
      >
        <ThemedText style={[styles.riskText, { color: riskConfig.textColor }]}>
          {riskLevel} Risk
        </ThemedText>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    alignItems: "center",
    gap: Spacing.md,
  },
  verdictRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  verdictText: {
    fontSize: 28,
    fontWeight: "700",
  },
  riskBadge: {
    paddingVertical: Spacing.xs,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.full,
  },
  riskText: {
    fontSize: 14,
    fontWeight: "600",
  },
});
