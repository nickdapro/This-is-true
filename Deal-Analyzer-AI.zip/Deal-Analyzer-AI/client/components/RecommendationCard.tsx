import React from "react";
import { View, StyleSheet } from "react-native";
import { Feather } from "@expo/vector-icons";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";

interface RecommendationCardProps {
  recommendation: "Buy" | "Negotiate" | "Walk away";
}

export function RecommendationCard({ recommendation }: RecommendationCardProps) {
  const { theme, isDark } = useTheme();

  const getConfig = () => {
    switch (recommendation) {
      case "Buy":
        return {
          color: Colors[isDark ? "dark" : "light"].success,
          icon: "thumbs-up" as const,
        };
      case "Walk away":
        return {
          color: Colors[isDark ? "dark" : "light"].danger,
          icon: "thumbs-down" as const,
        };
      default:
        return {
          color: Colors[isDark ? "dark" : "light"].warning,
          icon: "message-circle" as const,
        };
    }
  };

  const config = getConfig();

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: theme.backgroundDefault,
          borderColor: theme.border,
        },
      ]}
    >
      <View style={styles.headerRow}>
        <Feather name={config.icon} size={20} color={config.color} />
        <ThemedText style={[styles.title, { color: theme.textSecondary }]}>
          Recommendation
        </ThemedText>
      </View>
      <ThemedText style={[styles.recommendation, { color: config.color }]}>
        {recommendation}
      </ThemedText>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
  },
  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  title: {
    fontSize: 12,
    fontWeight: "500",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  recommendation: {
    fontSize: 20,
    fontWeight: "700",
  },
});
