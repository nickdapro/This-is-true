import React from "react";
import { View, Pressable, StyleSheet, ScrollView } from "react-native";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";

export type AssetType = "real_estate" | "stocks" | "crypto" | "commodities";

interface AssetTypeTabsProps {
  selected: AssetType;
  onChange: (type: AssetType) => void;
}

const ASSET_TYPES: { type: AssetType; label: string; icon: string; color: string }[] = [
  { type: "real_estate", label: "Property", icon: "home", color: "#D4AF37" },
  { type: "stocks", label: "Stocks", icon: "trending-up", color: "#3B82F6" },
  { type: "crypto", label: "Crypto", icon: "dollar-sign", color: "#F97316" },
  { type: "commodities", label: "Commodities", icon: "package", color: "#8B5CF6" },
];

export function AssetTypeTabs({ selected, onChange }: AssetTypeTabsProps) {
  const { theme, isDark } = useTheme();
  const colors = Colors[isDark ? "dark" : "light"];

  const handlePress = (type: AssetType) => {
    if (type !== selected) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      onChange(type);
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {ASSET_TYPES.map((asset) => {
          const isSelected = selected === asset.type;
          return (
            <Pressable
              key={asset.type}
              onPress={() => handlePress(asset.type)}
              style={[
                styles.tab,
                {
                  backgroundColor: isSelected ? asset.color : theme.backgroundDefault,
                  borderColor: isSelected ? asset.color : theme.border,
                },
              ]}
            >
              <Feather
                name={asset.icon as any}
                size={16}
                color={isSelected ? "#FFFFFF" : theme.textSecondary}
              />
              <ThemedText
                style={[
                  styles.tabLabel,
                  { color: isSelected ? "#FFFFFF" : theme.text },
                ]}
              >
                {asset.label}
              </ThemedText>
            </Pressable>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.md,
  },
  scrollContent: {
    paddingHorizontal: Spacing.xs,
    gap: Spacing.sm,
  },
  tab: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  tabLabel: {
    fontSize: 13,
    fontWeight: "600",
  },
});
