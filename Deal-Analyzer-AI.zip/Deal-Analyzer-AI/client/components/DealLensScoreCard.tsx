import React from "react";
import { View, StyleSheet, Dimensions } from "react-native";
import Svg, { Circle, Text as SvgText, G } from "react-native-svg";
import Animated, { FadeIn } from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";

interface DealLensScoreCardProps {
  overall: number;
  risk: number;
  yield: number;
  growth: number;
  liquidity: number;
  recommendation: string;
  confidenceLevel: number;
}

export function DealLensScoreCard({
  overall,
  risk,
  yield: yieldScore,
  growth,
  liquidity,
  recommendation,
  confidenceLevel,
}: DealLensScoreCardProps) {
  const { theme, isDark } = useTheme();
  const colors = Colors[isDark ? "dark" : "light"];

  const size = 140;
  const strokeWidth = 10;
  const radius = (size - strokeWidth) / 2;
  const center = size / 2;
  const circumference = 2 * Math.PI * radius;
  const progress = overall / 100;

  const getScoreColor = (score: number) => {
    if (score >= 70) return colors.success;
    if (score >= 45) return colors.warning;
    return colors.danger;
  };

  const getRecommendationStyle = () => {
    switch (recommendation) {
      case "Buy":
        return { backgroundColor: colors.successBackground, color: colors.success };
      case "Hold":
        return { backgroundColor: colors.warningBackground, color: colors.warning };
      case "Avoid":
        return { backgroundColor: colors.dangerBackground, color: colors.danger };
      default:
        return { backgroundColor: theme.backgroundTertiary, color: theme.text };
    }
  };

  const recStyle = getRecommendationStyle();

  const metrics = [
    { label: "Risk", value: 100 - risk, color: getScoreColor(100 - risk) },
    { label: "Yield", value: yieldScore, color: getScoreColor(yieldScore) },
    { label: "Growth", value: growth, color: getScoreColor(growth) },
    { label: "Liquidity", value: liquidity, color: getScoreColor(liquidity) },
  ];

  return (
    <Animated.View
      entering={FadeIn.duration(400)}
      style={[styles.container, { backgroundColor: theme.backgroundDefault, borderColor: theme.border }]}
    >
      <View style={styles.header}>
        <ThemedText style={styles.title}>DealLens Score</ThemedText>
        <View style={[styles.recommendationBadge, { backgroundColor: recStyle.backgroundColor }]}>
          <ThemedText style={[styles.recommendationText, { color: recStyle.color }]}>
            {recommendation}
          </ThemedText>
        </View>
      </View>

      <View style={styles.content}>
        <View style={styles.scoreCircle}>
          <Svg width={size} height={size}>
            <Circle
              cx={center}
              cy={center}
              r={radius}
              stroke={theme.border}
              strokeWidth={strokeWidth}
              fill="none"
            />
            <Circle
              cx={center}
              cy={center}
              r={radius}
              stroke={getScoreColor(overall)}
              strokeWidth={strokeWidth}
              fill="none"
              strokeDasharray={`${progress * circumference} ${circumference}`}
              strokeLinecap="round"
              rotation={-90}
              origin={`${center}, ${center}`}
            />
            <SvgText
              x={center}
              y={center - 5}
              fontSize={36}
              fontWeight="bold"
              fill={theme.text}
              textAnchor="middle"
            >
              {overall}
            </SvgText>
            <SvgText
              x={center}
              y={center + 18}
              fontSize={12}
              fill={theme.textSecondary}
              textAnchor="middle"
            >
              / 100
            </SvgText>
          </Svg>
        </View>

        <View style={styles.metricsColumn}>
          {metrics.map((metric, index) => (
            <View key={index} style={styles.metricRow}>
              <ThemedText style={[styles.metricLabel, { color: theme.textSecondary }]}>
                {metric.label}
              </ThemedText>
              <View style={styles.metricBar}>
                <View
                  style={[
                    styles.metricBarFill,
                    {
                      backgroundColor: metric.color,
                      width: `${metric.value}%`,
                    },
                  ]}
                />
              </View>
              <ThemedText style={[styles.metricValue, { color: metric.color }]}>
                {metric.value}
              </ThemedText>
            </View>
          ))}
        </View>
      </View>

      <View style={[styles.confidenceRow, { backgroundColor: theme.backgroundSecondary }]}>
        <ThemedText style={[styles.confidenceLabel, { color: theme.textSecondary }]}>
          AI Confidence
        </ThemedText>
        <ThemedText style={[styles.confidenceValue, { color: colors.primary }]}>
          {Math.round(confidenceLevel * 100)}%
        </ThemedText>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    padding: Spacing.md,
    marginBottom: Spacing.md,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  title: {
    fontSize: 18,
    fontWeight: "700",
  },
  recommendationBadge: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  recommendationText: {
    fontSize: 13,
    fontWeight: "700",
  },
  content: {
    flexDirection: "row",
    alignItems: "center",
  },
  scoreCircle: {
    marginRight: Spacing.md,
  },
  metricsColumn: {
    flex: 1,
    gap: Spacing.sm,
  },
  metricRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  metricLabel: {
    fontSize: 11,
    width: 55,
  },
  metricBar: {
    flex: 1,
    height: 6,
    backgroundColor: "#E5E7EB",
    borderRadius: 3,
    overflow: "hidden",
  },
  metricBarFill: {
    height: "100%",
    borderRadius: 3,
  },
  metricValue: {
    fontSize: 12,
    fontWeight: "600",
    width: 28,
    textAlign: "right",
  },
  confidenceRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: Spacing.md,
    padding: Spacing.sm,
    borderRadius: BorderRadius.sm,
  },
  confidenceLabel: {
    fontSize: 12,
  },
  confidenceValue: {
    fontSize: 14,
    fontWeight: "600",
  },
});
