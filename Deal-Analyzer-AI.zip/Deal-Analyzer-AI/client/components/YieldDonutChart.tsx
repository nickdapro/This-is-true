import React from "react";
import { View, StyleSheet, Dimensions } from "react-native";
import Svg, { Circle, Text as SvgText, G, Defs, LinearGradient, Stop } from "react-native-svg";
import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";

interface YieldDonutChartProps {
  grossYield: number;
  netYield: number;
  cashOnCashROI: number;
}

export function YieldDonutChart({ grossYield, netYield, cashOnCashROI }: YieldDonutChartProps) {
  const { theme, isDark } = useTheme();
  const colors = Colors[isDark ? "dark" : "light"];
  
  const size = Math.min(Dimensions.get("window").width - Spacing.lg * 4, 200);
  const strokeWidth = 14;
  const radius = (size - strokeWidth) / 2;
  const center = size / 2;
  const circumference = 2 * Math.PI * radius;

  const maxYield = 15;
  const normalizedGross = Math.min(grossYield, maxYield) / maxYield;
  const normalizedNet = Math.min(netYield, maxYield) / maxYield;

  const getYieldColor = (value: number) => {
    if (value >= 6) return colors.success;
    if (value >= 3) return colors.warning;
    return colors.danger;
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundDefault, borderColor: theme.border }]}>
      <ThemedText style={styles.title}>Yield Analysis</ThemedText>
      <View style={styles.chartRow}>
        <View style={styles.donutContainer}>
          <Svg width={size} height={size}>
            <Circle
              cx={center}
              cy={center}
              r={radius}
              stroke={theme.border}
              strokeWidth={strokeWidth}
              fill="none"
            />
            <Circle
              cx={center}
              cy={center}
              r={radius}
              stroke={getYieldColor(grossYield)}
              strokeWidth={strokeWidth}
              fill="none"
              strokeDasharray={`${normalizedGross * circumference} ${circumference}`}
              strokeLinecap="round"
              rotation={-90}
              origin={`${center}, ${center}`}
            />
            <SvgText
              x={center}
              y={center - 8}
              fontSize={24}
              fontWeight="bold"
              fill={theme.text}
              textAnchor="middle"
            >
              {grossYield.toFixed(1)}%
            </SvgText>
            <SvgText
              x={center}
              y={center + 14}
              fontSize={11}
              fill={theme.textSecondary}
              textAnchor="middle"
            >
              Gross Yield
            </SvgText>
          </Svg>
        </View>

        <View style={styles.statsColumn}>
          <View style={styles.statBox}>
            <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>Net Yield</ThemedText>
            <ThemedText style={[styles.statValue, { color: getYieldColor(netYield) }]}>
              {netYield.toFixed(2)}%
            </ThemedText>
          </View>
          <View style={styles.statBox}>
            <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>Cash-on-Cash</ThemedText>
            <ThemedText style={[styles.statValue, { color: getYieldColor(cashOnCashROI) }]}>
              {cashOnCashROI.toFixed(2)}%
            </ThemedText>
          </View>
        </View>
      </View>

      <View style={styles.benchmarks}>
        <View style={[styles.benchmark, { backgroundColor: colors.successBackground }]}>
          <View style={[styles.benchmarkDot, { backgroundColor: colors.success }]} />
          <ThemedText style={[styles.benchmarkText, { color: colors.success }]}>Good: 6%+</ThemedText>
        </View>
        <View style={[styles.benchmark, { backgroundColor: colors.warningBackground }]}>
          <View style={[styles.benchmarkDot, { backgroundColor: colors.warning }]} />
          <ThemedText style={[styles.benchmarkText, { color: colors.warning }]}>Fair: 3-6%</ThemedText>
        </View>
        <View style={[styles.benchmark, { backgroundColor: colors.dangerBackground }]}>
          <View style={[styles.benchmarkDot, { backgroundColor: colors.danger }]} />
          <ThemedText style={[styles.benchmarkText, { color: colors.danger }]}>Low: &lt;3%</ThemedText>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    padding: Spacing.md,
    marginBottom: Spacing.md,
  },
  title: {
    fontSize: 16,
    fontWeight: "600",
    marginBottom: Spacing.md,
  },
  chartRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  donutContainer: {
    alignItems: "center",
    justifyContent: "center",
  },
  statsColumn: {
    flex: 1,
    marginLeft: Spacing.md,
    gap: Spacing.sm,
  },
  statBox: {
    padding: Spacing.sm,
  },
  statLabel: {
    fontSize: 12,
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginBottom: 2,
  },
  statValue: {
    fontSize: 22,
    fontWeight: "700",
  },
  benchmarks: {
    flexDirection: "row",
    justifyContent: "center",
    gap: Spacing.sm,
    marginTop: Spacing.md,
    flexWrap: "wrap",
  },
  benchmark: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
    gap: 4,
  },
  benchmarkDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  benchmarkText: {
    fontSize: 10,
    fontWeight: "600",
  },
});
