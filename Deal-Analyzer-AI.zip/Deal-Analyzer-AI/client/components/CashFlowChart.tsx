import React from "react";
import { View, StyleSheet, Dimensions } from "react-native";
import Svg, { Path, Circle, Line, Text as SvgText, Defs, LinearGradient, Stop, Rect } from "react-native-svg";
import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";

interface CashFlowChartProps {
  netCashFlow: number;
  investmentPeriod: number;
  growthPercent: number;
}

export function CashFlowChart({ netCashFlow, investmentPeriod, growthPercent }: CashFlowChartProps) {
  const { theme, isDark } = useTheme();
  const colors = Colors[isDark ? "dark" : "light"];
  
  const width = Dimensions.get("window").width - Spacing.lg * 2 - Spacing.md * 2;
  const height = 180;
  const padding = { top: 20, right: 20, bottom: 30, left: 50 };
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;

  const dataPoints: number[] = [];
  for (let i = 0; i <= investmentPeriod; i++) {
    const adjustedCashFlow = netCashFlow * Math.pow(1 + growthPercent / 100, i);
    dataPoints.push(adjustedCashFlow);
  }

  const minValue = Math.min(...dataPoints, 0);
  const maxValue = Math.max(...dataPoints);
  const range = maxValue - minValue || 1;

  const getX = (index: number) => padding.left + (index / investmentPeriod) * chartWidth;
  const getY = (value: number) => padding.top + chartHeight - ((value - minValue) / range) * chartHeight;

  const pathData = dataPoints
    .map((value, index) => `${index === 0 ? "M" : "L"} ${getX(index)} ${getY(value)}`)
    .join(" ");

  const areaPath = `${pathData} L ${getX(investmentPeriod)} ${height - padding.bottom} L ${getX(0)} ${height - padding.bottom} Z`;

  const formatValue = (value: number) => {
    if (Math.abs(value) >= 1000) {
      return `$${(value / 1000).toFixed(0)}K`;
    }
    return `$${value.toFixed(0)}`;
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundDefault, borderColor: theme.border }]}>
      <ThemedText style={styles.title}>Cash Flow Over Time</ThemedText>
      <Svg width={width} height={height}>
        <Defs>
          <LinearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <Stop offset="0%" stopColor={colors.chartGreen} stopOpacity={0.3} />
            <Stop offset="100%" stopColor={colors.chartGreen} stopOpacity={0.05} />
          </LinearGradient>
        </Defs>

        {[0, 0.25, 0.5, 0.75, 1].map((ratio, i) => {
          const y = padding.top + chartHeight * (1 - ratio);
          const value = minValue + range * ratio;
          return (
            <React.Fragment key={i}>
              <Line
                x1={padding.left}
                y1={y}
                x2={width - padding.right}
                y2={y}
                stroke={theme.border}
                strokeWidth={1}
                strokeDasharray="4,4"
              />
              <SvgText
                x={padding.left - 8}
                y={y + 4}
                fontSize={10}
                fill={theme.textSecondary}
                textAnchor="end"
              >
                {formatValue(value)}
              </SvgText>
            </React.Fragment>
          );
        })}

        <Path d={areaPath} fill="url(#gradient)" />
        <Path d={pathData} fill="none" stroke={colors.chartGreen} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />

        {dataPoints.map((value, index) => (
          <Circle key={index} cx={getX(index)} cy={getY(value)} r={4} fill={colors.chartGreen} />
        ))}

        {dataPoints.map((_, index) => (
          <SvgText
            key={`label-${index}`}
            x={getX(index)}
            y={height - 8}
            fontSize={10}
            fill={theme.textSecondary}
            textAnchor="middle"
          >
            {`Yr ${index}`}
          </SvgText>
        ))}
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    padding: Spacing.md,
    marginBottom: Spacing.md,
  },
  title: {
    fontSize: 16,
    fontWeight: "600",
    marginBottom: Spacing.sm,
  },
});
