import React from "react";
import { View, StyleSheet } from "react-native";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";

interface MetricCardProps {
  label: string;
  value: string;
  isPositive?: boolean;
  isNegative?: boolean;
}

export function MetricCard({ label, value, isPositive, isNegative }: MetricCardProps) {
  const { theme, isDark } = useTheme();

  const valueColor = isPositive
    ? Colors[isDark ? "dark" : "light"].success
    : isNegative
    ? Colors[isDark ? "dark" : "light"].danger
    : theme.text;

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: theme.backgroundDefault,
          borderColor: theme.border,
        },
      ]}
    >
      <ThemedText style={[styles.label, { color: theme.textSecondary }]}>
        {label}
      </ThemedText>
      <ThemedText style={[styles.value, { color: valueColor }]}>
        {value}
      </ThemedText>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: Spacing.md,
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
  },
  label: {
    fontSize: 12,
    fontWeight: "500",
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginBottom: Spacing.xs,
  },
  value: {
    fontSize: 24,
    fontWeight: "700",
  },
});
