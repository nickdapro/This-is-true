import React from "react";
import { View, Pressable, StyleSheet } from "react-native";
import { Feather } from "@expo/vector-icons";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";

type PropertyType = "house" | "apartment" | "building";

interface PropertyTypeSelectorProps {
  value: PropertyType;
  onChange: (type: PropertyType) => void;
}

const propertyTypes: { type: PropertyType; label: string; icon: keyof typeof Feather.glyphMap }[] = [
  { type: "house", label: "House", icon: "home" },
  { type: "apartment", label: "Apartment", icon: "square" },
  { type: "building", label: "Building", icon: "layers" },
];

export function PropertyTypeSelector({ value, onChange }: PropertyTypeSelectorProps) {
  const { theme } = useTheme();

  return (
    <View style={styles.container}>
      <ThemedText style={[styles.label, { color: theme.textSecondary }]}>
        Property Type
      </ThemedText>
      <View style={styles.optionsContainer}>
        {propertyTypes.map(({ type, label, icon }) => {
          const isSelected = value === type;
          return (
            <Pressable
              key={type}
              onPress={() => onChange(type)}
              style={[
                styles.option,
                {
                  backgroundColor: isSelected ? theme.link : theme.backgroundDefault,
                  borderColor: isSelected ? theme.link : theme.border,
                },
              ]}
            >
              <Feather
                name={icon}
                size={18}
                color={isSelected ? "#FFFFFF" : theme.textSecondary}
              />
              <ThemedText
                style={[
                  styles.optionLabel,
                  { color: isSelected ? "#FFFFFF" : theme.text },
                ]}
              >
                {label}
              </ThemedText>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.md,
  },
  label: {
    fontSize: 14,
    fontWeight: "500",
    marginBottom: Spacing.xs,
  },
  optionsContainer: {
    flexDirection: "row",
    gap: Spacing.sm,
  },
  option: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    height: Spacing.inputHeight,
    borderWidth: 1,
    borderRadius: BorderRadius.xs,
    gap: Spacing.xs,
  },
  optionLabel: {
    fontSize: 14,
    fontWeight: "500",
  },
});
