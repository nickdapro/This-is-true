import React, { useEffect, useState, useCallback } from "react";
import {
  View,
  StyleSheet,
  ScrollView,
  RefreshControl,
  Pressable,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, { FadeInDown } from "react-native-reanimated";
import Svg, { Path } from "react-native-svg";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/contexts/AuthContext";
import { getApiUrl } from "@/lib/query-client";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";

interface PortfolioSummary {
  totalValue: number;
  allocation: {
    realEstate: number;
    stocks: number;
    crypto: number;
    commodities: number;
  };
  counts: {
    realEstate: number;
    stocks: number;
    crypto: number;
    commodities: number;
  };
  averageScore: number;
}

interface SavedAnalysis {
  id: number;
  location: string;
  propertyPrice: number;
  verdict: string;
  riskLevel: string;
  dealLensScore: number | null;
  createdAt: string;
}

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme, isDark } = useTheme();
  const colors = Colors[isDark ? "dark" : "light"];
  const { sessionId } = useAuth();

  const [portfolio, setPortfolio] = useState<PortfolioSummary | null>(null);
  const [analyses, setAnalyses] = useState<SavedAnalysis[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    try {
      const baseUrl = getApiUrl();
      const [portfolioRes, analysesRes] = await Promise.all([
        fetch(new URL("/api/portfolio/summary", baseUrl), {
          headers: { Authorization: `Bearer ${sessionId}` },
        }),
        fetch(new URL("/api/analyses", baseUrl), {
          headers: { Authorization: `Bearer ${sessionId}` },
        }),
      ]);

      if (portfolioRes.ok) {
        setPortfolio(await portfolioRes.json());
      }
      if (analysesRes.ok) {
        setAnalyses(await analysesRes.json());
      }
    } catch (err) {
      console.error("Dashboard load error:", err);
    } finally {
      setIsLoading(false);
      setRefreshing(false);
    }
  }, [sessionId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const onRefresh = () => {
    setRefreshing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    loadData();
  };

  const handleDelete = async (id: number) => {
    Alert.alert("Delete Analysis", "Are you sure you want to delete this analysis?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: async () => {
          try {
            const baseUrl = getApiUrl();
            const response = await fetch(new URL(`/api/analyses/${id}`, baseUrl), {
              method: "DELETE",
              headers: { Authorization: `Bearer ${sessionId}` },
            });
            if (response.ok) {
              setAnalyses(analyses.filter((a) => a.id !== id));
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            }
          } catch {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
          }
        },
      },
    ]);
  };

  const formatCurrency = (value: number): string => {
    if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `$${(value / 1000).toFixed(0)}K`;
    return `$${value.toFixed(0)}`;
  };

  const getVerdictColor = (verdict: string) => {
    switch (verdict) {
      case "Good": return colors.success;
      case "Bad": return colors.danger;
      default: return colors.warning;
    }
  };

  const AllocationDonut = () => {
    if (!portfolio || portfolio.totalValue === 0) return null;
    
    const size = 140;
    const center = size / 2;
    const radius = 50;
    const strokeWidth = 24;

    const data = [
      { value: portfolio.allocation.realEstate, color: colors.primary, label: "Property" },
      { value: portfolio.allocation.stocks, color: colors.chartBlue, label: "Stocks" },
      { value: portfolio.allocation.crypto, color: colors.chartOrange, label: "Crypto" },
      { value: portfolio.allocation.commodities, color: colors.chartPurple, label: "Commodities" },
    ].filter(d => d.value > 0);

    if (data.length === 0) return null;

    let currentAngle = -90;
    const segments = data.map((item) => {
      const percentage = item.value / portfolio.totalValue;
      const angle = percentage * 360;
      const startAngle = currentAngle;
      currentAngle += angle;

      const startRad = (startAngle * Math.PI) / 180;
      const endRad = ((startAngle + angle) * Math.PI) / 180;

      const x1 = center + radius * Math.cos(startRad);
      const y1 = center + radius * Math.sin(startRad);
      const x2 = center + radius * Math.cos(endRad);
      const y2 = center + radius * Math.sin(endRad);

      const largeArc = angle > 180 ? 1 : 0;

      return {
        ...item,
        percentage,
        path: `M ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2}`,
      };
    });

    return (
      <View style={styles.donutContainer}>
        <Svg width={size} height={size}>
          {segments.map((seg, i) => (
            <Path
              key={i}
              d={seg.path}
              stroke={seg.color}
              strokeWidth={strokeWidth}
              fill="none"
              strokeLinecap="round"
            />
          ))}
        </Svg>
        <View style={styles.donutCenter}>
          <ThemedText style={styles.donutValue}>
            {formatCurrency(portfolio.totalValue)}
          </ThemedText>
          <ThemedText style={[styles.donutLabel, { color: theme.textSecondary }]}>
            Total Value
          </ThemedText>
        </View>
      </View>
    );
  };

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: headerHeight + Spacing.md, paddingBottom: tabBarHeight + Spacing.xl },
        ]}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
        }
      >
        {portfolio ? (
          <Animated.View entering={FadeInDown.duration(300)}>
            <View style={[styles.portfolioCard, { backgroundColor: theme.backgroundDefault, borderColor: theme.border }]}>
              <ThemedText style={styles.sectionTitle}>Portfolio Overview</ThemedText>
              
              <AllocationDonut />

              <View style={styles.allocationLegend}>
                {[
                  { label: "Property", value: portfolio.allocation.realEstate, color: colors.primary },
                  { label: "Stocks", value: portfolio.allocation.stocks, color: colors.chartBlue },
                  { label: "Crypto", value: portfolio.allocation.crypto, color: colors.chartOrange },
                  { label: "Commodities", value: portfolio.allocation.commodities, color: colors.chartPurple },
                ].filter(item => item.value > 0).map((item, i) => (
                  <View key={i} style={styles.legendItem}>
                    <View style={[styles.legendDot, { backgroundColor: item.color }]} />
                    <ThemedText style={[styles.legendText, { color: theme.textSecondary }]}>
                      {item.label}
                    </ThemedText>
                    <ThemedText style={styles.legendValue}>
                      {formatCurrency(item.value)}
                    </ThemedText>
                  </View>
                ))}
              </View>

              {portfolio.averageScore > 0 ? (
                <View style={[styles.avgScoreBox, { backgroundColor: theme.backgroundSecondary }]}>
                  <ThemedText style={[styles.avgScoreLabel, { color: theme.textSecondary }]}>
                    Average DealLens Score
                  </ThemedText>
                  <ThemedText style={[styles.avgScoreValue, { color: colors.primary }]}>
                    {portfolio.averageScore}/100
                  </ThemedText>
                </View>
              ) : null}
            </View>
          </Animated.View>
        ) : null}

        <Animated.View entering={FadeInDown.delay(100).duration(300)}>
          <View style={styles.sectionHeader}>
            <ThemedText style={styles.sectionTitle}>Saved Analyses</ThemedText>
            <ThemedText style={[styles.countBadge, { color: theme.textSecondary }]}>
              {analyses.length} / 50
            </ThemedText>
          </View>

          {analyses.length === 0 ? (
            <View style={[styles.emptyState, { backgroundColor: theme.backgroundDefault, borderColor: theme.border }]}>
              <Feather name="folder" size={40} color={theme.textSecondary} />
              <ThemedText style={[styles.emptyText, { color: theme.textSecondary }]}>
                No saved analyses yet
              </ThemedText>
              <ThemedText style={[styles.emptySubtext, { color: theme.textSecondary }]}>
                Analyze a property to save it here
              </ThemedText>
            </View>
          ) : (
            <View style={styles.analysesList}>
              {analyses.map((analysis, index) => (
                <Animated.View
                  key={analysis.id}
                  entering={FadeInDown.delay(index * 50).duration(300)}
                >
                  <View
                    style={[
                      styles.analysisCard,
                      { backgroundColor: theme.backgroundDefault, borderColor: theme.border },
                    ]}
                  >
                    <View style={styles.cardHeader}>
                      <View style={styles.cardInfo}>
                        <ThemedText style={styles.locationText} numberOfLines={1}>
                          {analysis.location}
                        </ThemedText>
                        <ThemedText style={[styles.priceText, { color: theme.textSecondary }]}>
                          {formatCurrency(analysis.propertyPrice)}
                        </ThemedText>
                      </View>
                      <Pressable
                        onPress={() => handleDelete(analysis.id)}
                        style={styles.deleteButton}
                        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                      >
                        <Feather name="trash-2" size={18} color={colors.danger} />
                      </Pressable>
                    </View>

                    <View style={styles.cardMetrics}>
                      {analysis.dealLensScore !== null ? (
                        <View style={[styles.scoreBadge, { backgroundColor: colors.primaryLight }]}>
                          <ThemedText style={[styles.scoreText, { color: colors.primary }]}>
                            Score: {analysis.dealLensScore}
                          </ThemedText>
                        </View>
                      ) : null}
                      <View
                        style={[
                          styles.verdictBadge,
                          { backgroundColor: getVerdictColor(analysis.verdict) + "20" },
                        ]}
                      >
                        <ThemedText
                          style={[styles.verdictText, { color: getVerdictColor(analysis.verdict) }]}
                        >
                          {analysis.verdict}
                        </ThemedText>
                      </View>
                      <View
                        style={[
                          styles.riskBadge,
                          {
                            backgroundColor:
                              analysis.riskLevel === "Low"
                                ? colors.successBackground
                                : analysis.riskLevel === "High"
                                ? colors.dangerBackground
                                : colors.warningBackground,
                          },
                        ]}
                      >
                        <ThemedText
                          style={[
                            styles.riskText,
                            {
                              color:
                                analysis.riskLevel === "Low"
                                  ? colors.success
                                  : analysis.riskLevel === "High"
                                  ? colors.danger
                                  : colors.warning,
                            },
                          ]}
                        >
                          {analysis.riskLevel} Risk
                        </ThemedText>
                      </View>
                    </View>
                  </View>
                </Animated.View>
              ))}
            </View>
          )}
        </Animated.View>
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: Spacing.lg },
  portfolioCard: {
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    marginBottom: Spacing.lg,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "700",
    marginBottom: Spacing.md,
  },
  donutContainer: {
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.md,
  },
  donutCenter: {
    position: "absolute",
    alignItems: "center",
  },
  donutValue: {
    fontSize: 18,
    fontWeight: "700",
  },
  donutLabel: {
    fontSize: 11,
  },
  allocationLegend: {
    gap: Spacing.sm,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  legendText: {
    fontSize: 13,
    flex: 1,
  },
  legendValue: {
    fontSize: 13,
    fontWeight: "600",
  },
  avgScoreBox: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: Spacing.sm,
    borderRadius: BorderRadius.sm,
    marginTop: Spacing.md,
  },
  avgScoreLabel: {
    fontSize: 13,
  },
  avgScoreValue: {
    fontSize: 16,
    fontWeight: "700",
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  countBadge: {
    fontSize: 12,
  },
  emptyState: {
    padding: Spacing.xl,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    alignItems: "center",
    gap: Spacing.sm,
  },
  emptyText: {
    fontSize: 16,
    fontWeight: "500",
  },
  emptySubtext: {
    fontSize: 13,
    textAlign: "center",
  },
  analysesList: {
    gap: Spacing.sm,
  },
  analysisCard: {
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
  },
  cardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: Spacing.sm,
  },
  cardInfo: {
    flex: 1,
  },
  locationText: {
    fontSize: 15,
    fontWeight: "600",
    marginBottom: 2,
  },
  priceText: {
    fontSize: 13,
  },
  deleteButton: {
    padding: Spacing.xs,
  },
  cardMetrics: {
    flexDirection: "row",
    gap: Spacing.sm,
    flexWrap: "wrap",
  },
  scoreBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  scoreText: {
    fontSize: 11,
    fontWeight: "600",
  },
  verdictBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  verdictText: {
    fontSize: 11,
    fontWeight: "600",
  },
  riskBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  riskText: {
    fontSize: 11,
    fontWeight: "600",
  },
});
