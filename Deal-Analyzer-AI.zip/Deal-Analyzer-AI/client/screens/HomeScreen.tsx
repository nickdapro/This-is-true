import React, { useState, useEffect, useCallback } from "react";
import {
  View,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  Pressable,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, { FadeInDown, FadeIn } from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Button } from "@/components/Button";
import { FormInput } from "@/components/FormInput";
import { PropertyTypeSelector } from "@/components/PropertyTypeSelector";
import { MetricCard } from "@/components/MetricCard";
import { VerdictCard } from "@/components/VerdictCard";
import { RecommendationCard } from "@/components/RecommendationCard";
import { CashFlowChart } from "@/components/CashFlowChart";
import { CapitalGainsChart } from "@/components/CapitalGainsChart";
import { YieldDonutChart } from "@/components/YieldDonutChart";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/contexts/AuthContext";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";
import { apiRequest, getApiUrl } from "@/lib/query-client";

type PropertyType = "house" | "apartment" | "building";

interface FormData {
  propertyPrice: string;
  location: string;
  propertyType: PropertyType;
  numberOfUnits: string;
  rentPerUnitPerWeek: string;
  expensesPercent: string;
  expectedGrowthPercent: string;
  investmentPeriod: string;
}

interface Calculations {
  annualRentalIncome: number;
  annualExpenses: number;
  netAnnualCashFlow: number;
  futureValue: number;
  capitalGain: number;
  cashOnCashROI: number;
  grossYield: number;
  netYield: number;
}

interface AnalysisResult {
  input: FormData & { propertyPrice: number; rentPerUnitPerWeek: number };
  calculations: Calculations;
  aiAnalysis: {
    verdict: "Good" | "Neutral" | "Bad";
    riskLevel: "Low" | "Medium" | "High";
    bulletPoints: string[];
    recommendation: "Buy" | "Negotiate" | "Walk away";
  };
}

const initialFormData: FormData = {
  propertyPrice: "",
  location: "",
  propertyType: "house",
  numberOfUnits: "1",
  rentPerUnitPerWeek: "",
  expensesPercent: "30",
  expectedGrowthPercent: "5",
  investmentPeriod: "5",
};

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme, isDark } = useTheme();
  const colors = Colors[isDark ? "dark" : "light"];
  const { sessionId } = useAuth();

  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [liveCalc, setLiveCalc] = useState<Calculations | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const calculateLocally = useCallback(() => {
    const price = parseFloat(formData.propertyPrice) || 0;
    const rent = parseFloat(formData.rentPerUnitPerWeek) || 0;
    const units = parseInt(formData.numberOfUnits) || 1;
    const expenses = parseFloat(formData.expensesPercent) || 30;
    const growth = parseFloat(formData.expectedGrowthPercent) || 5;
    const period = parseInt(formData.investmentPeriod) || 5;

    if (price <= 0 || rent <= 0) {
      setLiveCalc(null);
      return;
    }

    const annualRentalIncome = rent * units * 52;
    const annualExpenses = annualRentalIncome * (expenses / 100);
    const netAnnualCashFlow = annualRentalIncome - annualExpenses;
    const futureValue = price * Math.pow(1 + growth / 100, period);
    const capitalGain = futureValue - price;
    const cashOnCashROI = (netAnnualCashFlow / price) * 100;
    const grossYield = (annualRentalIncome / price) * 100;
    const netYield = (netAnnualCashFlow / price) * 100;

    setLiveCalc({
      annualRentalIncome,
      annualExpenses,
      netAnnualCashFlow,
      futureValue,
      capitalGain,
      cashOnCashROI,
      grossYield,
      netYield,
    });
  }, [formData]);

  useEffect(() => {
    calculateLocally();
  }, [calculateLocally]);

  const updateField = (field: keyof FormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setError(null);
  };

  const formatCurrency = (value: number): string => {
    if (value >= 1000000) {
      return `$${(value / 1000000).toFixed(2)}M`;
    }
    if (value >= 1000) {
      return `$${(value / 1000).toFixed(1)}K`;
    }
    return `$${value.toFixed(0)}`;
  };

  const formatPercent = (value: number): string => {
    return `${value.toFixed(2)}%`;
  };

  const validateForm = (): boolean => {
    if (!formData.propertyPrice || parseFloat(formData.propertyPrice) <= 0) {
      setError("Please enter a valid property price");
      return false;
    }
    if (!formData.location.trim()) {
      setError("Please enter a location");
      return false;
    }
    if (!formData.rentPerUnitPerWeek || parseFloat(formData.rentPerUnitPerWeek) <= 0) {
      setError("Please enter a valid weekly rent");
      return false;
    }
    return true;
  };

  const handleAnalyze = async () => {
    if (!validateForm()) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);
    setSaved(false);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      const response = await apiRequest("POST", "/api/analyze", {
        propertyPrice: parseFloat(formData.propertyPrice),
        location: formData.location,
        propertyType: formData.propertyType,
        numberOfUnits: parseInt(formData.numberOfUnits) || 1,
        rentPerUnitPerWeek: parseFloat(formData.rentPerUnitPerWeek),
        expensesPercent: parseFloat(formData.expensesPercent) || 30,
        expectedGrowthPercent: parseFloat(formData.expectedGrowthPercent) || 5,
        investmentPeriod: parseInt(formData.investmentPeriod) || 5,
      });

      const data = await response.json();
      setResult(data);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Analysis failed. Please try again.");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    if (!result || !sessionId) return;

    setIsSaving(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      const baseUrl = getApiUrl();
      const response = await fetch(new URL("/api/analyses", baseUrl), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${sessionId}`,
        },
        body: JSON.stringify(result),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Failed to save");
      }

      setSaved(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert("Saved", "Analysis saved to your dashboard");
    } catch (err) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert("Error", err instanceof Error ? err.message : "Failed to save analysis");
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = () => {
    setFormData(initialFormData);
    setResult(null);
    setError(null);
    setSaved(false);
    setLiveCalc(null);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.content,
          { paddingTop: headerHeight + Spacing.lg, paddingBottom: tabBarHeight + Spacing.xl },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {!result ? (
          <Animated.View entering={FadeIn.duration(300)}>
            <ThemedText style={[styles.subtitle, { color: theme.textSecondary }]}>
              Enter property details for instant AI-powered analysis
            </ThemedText>

            <View style={styles.section}>
              <ThemedText style={styles.sectionTitle}>Property Details</ThemedText>
              
              <FormInput
                label="Property Price"
                prefix="$"
                value={formData.propertyPrice}
                onChangeText={(v) => updateField("propertyPrice", v)}
                keyboardType="numeric"
                placeholder="500000"
              />

              <FormInput
                label="Location"
                value={formData.location}
                onChangeText={(v) => updateField("location", v)}
                placeholder="Sydney, NSW"
              />

              <PropertyTypeSelector
                value={formData.propertyType}
                onChange={(v) => updateField("propertyType", v)}
              />

              <FormInput
                label="Number of Units"
                value={formData.numberOfUnits}
                onChangeText={(v) => updateField("numberOfUnits", v)}
                keyboardType="numeric"
                placeholder="1"
              />
            </View>

            <View style={styles.section}>
              <ThemedText style={styles.sectionTitle}>Income</ThemedText>
              
              <FormInput
                label="Rent per Unit per Week"
                prefix="$"
                value={formData.rentPerUnitPerWeek}
                onChangeText={(v) => updateField("rentPerUnitPerWeek", v)}
                keyboardType="numeric"
                placeholder="500"
              />
            </View>

            <View style={styles.section}>
              <ThemedText style={styles.sectionTitle}>Assumptions</ThemedText>
              
              <FormInput
                label="Estimated Expenses"
                suffix="%"
                value={formData.expensesPercent}
                onChangeText={(v) => updateField("expensesPercent", v)}
                keyboardType="numeric"
                placeholder="30"
              />

              <FormInput
                label="Expected Annual Growth"
                suffix="%"
                value={formData.expectedGrowthPercent}
                onChangeText={(v) => updateField("expectedGrowthPercent", v)}
                keyboardType="numeric"
                placeholder="5"
              />

              <FormInput
                label="Investment Period"
                suffix="years"
                value={formData.investmentPeriod}
                onChangeText={(v) => updateField("investmentPeriod", v)}
                keyboardType="numeric"
                placeholder="5"
              />
            </View>

            {liveCalc ? (
              <Animated.View entering={FadeInDown.duration(300)} style={[styles.livePreview, { backgroundColor: colors.primaryLight, borderColor: colors.primary }]}>
                <View style={styles.liveHeader}>
                  <Feather name="zap" size={16} color={colors.primary} />
                  <ThemedText style={[styles.liveTitle, { color: colors.primary }]}>Live Preview</ThemedText>
                </View>
                <View style={styles.liveStats}>
                  <View style={styles.liveStat}>
                    <ThemedText style={[styles.liveLabel, { color: theme.textSecondary }]}>Gross Yield</ThemedText>
                    <ThemedText style={styles.liveValue}>{formatPercent(liveCalc.grossYield)}</ThemedText>
                  </View>
                  <View style={styles.liveStat}>
                    <ThemedText style={[styles.liveLabel, { color: theme.textSecondary }]}>Cash Flow</ThemedText>
                    <ThemedText style={[styles.liveValue, { color: liveCalc.netAnnualCashFlow >= 0 ? colors.success : colors.danger }]}>
                      {formatCurrency(liveCalc.netAnnualCashFlow)}/yr
                    </ThemedText>
                  </View>
                  <View style={styles.liveStat}>
                    <ThemedText style={[styles.liveLabel, { color: theme.textSecondary }]}>Future Value</ThemedText>
                    <ThemedText style={styles.liveValue}>{formatCurrency(liveCalc.futureValue)}</ThemedText>
                  </View>
                </View>
              </Animated.View>
            ) : null}

            {error ? (
              <Animated.View
                entering={FadeInDown.duration(200)}
                style={[styles.errorContainer, { backgroundColor: colors.dangerBackground }]}
              >
                <Feather name="alert-circle" size={16} color={colors.danger} />
                <ThemedText style={[styles.errorText, { color: colors.danger }]}>
                  {error}
                </ThemedText>
              </Animated.View>
            ) : null}

            <Button onPress={handleAnalyze} disabled={isLoading} style={[styles.analyzeButton, { backgroundColor: colors.primary }]}>
              {isLoading ? (
                <View style={styles.loadingRow}>
                  <ActivityIndicator color="#FFFFFF" size="small" />
                  <ThemedText style={styles.buttonText}>Getting AI Analysis...</ThemedText>
                </View>
              ) : (
                <View style={styles.loadingRow}>
                  <Feather name="cpu" size={18} color="#FFFFFF" />
                  <ThemedText style={styles.buttonText}>Get AI Analysis</ThemedText>
                </View>
              )}
            </Button>
          </Animated.View>
        ) : (
          <Animated.View entering={FadeInDown.duration(400)}>
            <View style={styles.resultsHeader}>
              <ThemedText type="h3">Analysis Results</ThemedText>
              <Pressable onPress={handleReset} style={styles.resetButton}>
                <Feather name="refresh-cw" size={18} color={colors.primary} />
                <ThemedText style={[styles.resetText, { color: colors.primary }]}>New</ThemedText>
              </Pressable>
            </View>

            <Animated.View entering={FadeInDown.delay(100).duration(300)}>
              <VerdictCard verdict={result.aiAnalysis.verdict} riskLevel={result.aiAnalysis.riskLevel} />
            </Animated.View>

            <Animated.View entering={FadeInDown.delay(150).duration(300)}>
              <YieldDonutChart
                grossYield={result.calculations.grossYield}
                netYield={result.calculations.netYield}
                cashOnCashROI={result.calculations.cashOnCashROI}
              />
            </Animated.View>

            <Animated.View entering={FadeInDown.delay(200).duration(300)}>
              <CashFlowChart
                netCashFlow={result.calculations.netAnnualCashFlow}
                investmentPeriod={parseInt(formData.investmentPeriod) || 5}
                growthPercent={parseFloat(formData.expectedGrowthPercent) || 5}
              />
            </Animated.View>

            <Animated.View entering={FadeInDown.delay(250).duration(300)}>
              <CapitalGainsChart
                propertyPrice={parseFloat(formData.propertyPrice)}
                futureValue={result.calculations.futureValue}
                investmentPeriod={parseInt(formData.investmentPeriod) || 5}
                growthPercent={parseFloat(formData.expectedGrowthPercent) || 5}
              />
            </Animated.View>

            <Animated.View entering={FadeInDown.delay(300).duration(300)}>
              <ThemedText style={styles.sectionTitle}>Summary</ThemedText>
              <View style={styles.metricsGrid}>
                <View style={styles.metricsRow}>
                  <View style={styles.metricHalf}>
                    <MetricCard label="Annual Income" value={formatCurrency(result.calculations.annualRentalIncome)} />
                  </View>
                  <View style={styles.metricHalf}>
                    <MetricCard label="Annual Expenses" value={formatCurrency(result.calculations.annualExpenses)} isNegative />
                  </View>
                </View>
                <View style={styles.metricsRow}>
                  <View style={styles.metricHalf}>
                    <MetricCard
                      label="Net Cash Flow"
                      value={formatCurrency(result.calculations.netAnnualCashFlow)}
                      isPositive={result.calculations.netAnnualCashFlow > 0}
                      isNegative={result.calculations.netAnnualCashFlow < 0}
                    />
                  </View>
                  <View style={styles.metricHalf}>
                    <MetricCard label="Capital Gain" value={formatCurrency(result.calculations.capitalGain)} isPositive />
                  </View>
                </View>
              </View>
            </Animated.View>

            <Animated.View entering={FadeInDown.delay(350).duration(300)}>
              <ThemedText style={styles.sectionTitle}>AI Insights</ThemedText>
              <View style={[styles.bulletContainer, { backgroundColor: theme.backgroundDefault, borderColor: theme.border }]}>
                {result.aiAnalysis.bulletPoints.map((point, index) => (
                  <View key={index} style={styles.bulletRow}>
                    <View style={[styles.bullet, { backgroundColor: colors.primary }]} />
                    <ThemedText style={styles.bulletText}>{point}</ThemedText>
                  </View>
                ))}
              </View>
            </Animated.View>

            <Animated.View entering={FadeInDown.delay(400).duration(300)}>
              <RecommendationCard recommendation={result.aiAnalysis.recommendation} />
            </Animated.View>

            {!saved ? (
              <Animated.View entering={FadeInDown.delay(450).duration(300)}>
                <Button onPress={handleSave} disabled={isSaving} style={[styles.saveButton, { backgroundColor: colors.success }]}>
                  {isSaving ? (
                    <View style={styles.loadingRow}>
                      <ActivityIndicator color="#FFFFFF" size="small" />
                      <ThemedText style={styles.buttonText}>Saving...</ThemedText>
                    </View>
                  ) : (
                    <View style={styles.loadingRow}>
                      <Feather name="save" size={18} color="#FFFFFF" />
                      <ThemedText style={styles.buttonText}>Save to Dashboard</ThemedText>
                    </View>
                  )}
                </Button>
              </Animated.View>
            ) : (
              <Animated.View entering={FadeInDown.duration(300)} style={[styles.savedBadge, { backgroundColor: colors.successBackground }]}>
                <Feather name="check-circle" size={18} color={colors.success} />
                <ThemedText style={[styles.savedText, { color: colors.success }]}>Saved to Dashboard</ThemedText>
              </Animated.View>
            )}

            <ThemedText style={[styles.disclaimer, { color: theme.textSecondary }]}>
              This analysis is for educational purposes only and does not constitute financial advice.
            </ThemedText>
          </Animated.View>
        )}
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  content: { paddingHorizontal: Spacing.lg },
  subtitle: { fontSize: 16, marginBottom: Spacing.lg, textAlign: "center" },
  section: { marginBottom: Spacing.lg },
  sectionTitle: { fontSize: 18, fontWeight: "600", marginBottom: Spacing.md, marginTop: Spacing.sm },
  livePreview: { padding: Spacing.md, borderRadius: BorderRadius.md, borderWidth: 1, marginBottom: Spacing.lg },
  liveHeader: { flexDirection: "row", alignItems: "center", gap: Spacing.xs, marginBottom: Spacing.sm },
  liveTitle: { fontSize: 14, fontWeight: "600" },
  liveStats: { flexDirection: "row", justifyContent: "space-between" },
  liveStat: { flex: 1, alignItems: "center" },
  liveLabel: { fontSize: 10, textTransform: "uppercase", letterSpacing: 0.5 },
  liveValue: { fontSize: 16, fontWeight: "700" },
  errorContainer: { flexDirection: "row", alignItems: "center", padding: Spacing.md, borderRadius: BorderRadius.sm, gap: Spacing.sm, marginBottom: Spacing.md },
  errorText: { flex: 1, fontSize: 14 },
  analyzeButton: { marginTop: Spacing.md },
  loadingRow: { flexDirection: "row", alignItems: "center", gap: Spacing.sm },
  buttonText: { color: "#FFFFFF", fontWeight: "600", fontSize: 16 },
  resultsHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: Spacing.lg },
  resetButton: { flexDirection: "row", alignItems: "center", gap: Spacing.xs, padding: Spacing.sm },
  resetText: { fontSize: 14, fontWeight: "500" },
  metricsGrid: { gap: Spacing.sm, marginBottom: Spacing.lg },
  metricsRow: { flexDirection: "row", gap: Spacing.sm },
  metricHalf: { flex: 1 },
  bulletContainer: { padding: Spacing.md, borderRadius: BorderRadius.sm, borderWidth: 1, marginBottom: Spacing.lg, gap: Spacing.md },
  bulletRow: { flexDirection: "row", alignItems: "flex-start", gap: Spacing.sm },
  bullet: { width: 6, height: 6, borderRadius: 3, marginTop: 8 },
  bulletText: { flex: 1, fontSize: 15, lineHeight: 22 },
  saveButton: { marginTop: Spacing.md },
  savedBadge: { flexDirection: "row", alignItems: "center", justifyContent: "center", padding: Spacing.md, borderRadius: BorderRadius.sm, gap: Spacing.sm, marginTop: Spacing.md },
  savedText: { fontSize: 14, fontWeight: "600" },
  disclaimer: { fontSize: 12, textAlign: "center", marginTop: Spacing.lg, fontStyle: "italic" },
});
