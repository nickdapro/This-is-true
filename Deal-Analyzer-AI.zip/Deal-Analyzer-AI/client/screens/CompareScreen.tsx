import React, { useEffect, useState } from "react";
import {
  View,
  StyleSheet,
  ScrollView,
  Pressable,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import Animated, { FadeInDown } from "react-native-reanimated";
import Svg, { Rect, Text as SvgText, Line } from "react-native-svg";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/contexts/AuthContext";
import { getApiUrl } from "@/lib/query-client";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";

interface SavedAnalysis {
  id: number;
  location: string;
  propertyPrice: number;
  propertyType: string;
  netAnnualCashFlow: number;
  cashOnCashROI: number;
  grossYield: number | null;
  netYield: number | null;
  capitalGain: number;
  verdict: string;
  riskLevel: string;
}

export default function CompareScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme, isDark } = useTheme();
  const colors = Colors[isDark ? "dark" : "light"];
  const { sessionId } = useAuth();

  const [analyses, setAnalyses] = useState<SavedAnalysis[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selected, setSelected] = useState<number[]>([]);

  useEffect(() => {
    loadAnalyses();
  }, []);

  const loadAnalyses = async () => {
    try {
      const baseUrl = getApiUrl();
      const response = await fetch(new URL("/api/analyses", baseUrl), {
        headers: { Authorization: `Bearer ${sessionId}` },
      });
      if (response.ok) {
        const data = await response.json();
        setAnalyses(data);
        if (data.length >= 2) {
          setSelected([data[0].id, data[1].id]);
        } else if (data.length === 1) {
          setSelected([data[0].id]);
        }
      }
    } catch (err) {
      console.error("Failed to load analyses:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleSelection = (id: number) => {
    if (selected.includes(id)) {
      setSelected(selected.filter((s) => s !== id));
    } else if (selected.length < 3) {
      setSelected([...selected, id]);
    }
  };

  const selectedAnalyses = analyses.filter((a) => selected.includes(a.id));

  const formatCurrency = (value: number): string => {
    if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `$${(value / 1000).toFixed(0)}K`;
    return `$${value.toFixed(0)}`;
  };

  const getVerdictColor = (verdict: string) => {
    switch (verdict) {
      case "Good": return colors.success;
      case "Bad": return colors.danger;
      default: return colors.warning;
    }
  };

  const chartColors = [colors.chartBlue, colors.chartPurple, colors.chartOrange];

  const ComparisonBarChart = ({ data, label, format }: { data: { value: number; label: string }[]; label: string; format: (v: number) => string }) => {
    const maxValue = Math.max(...data.map((d) => Math.abs(d.value)), 1);
    const width = 280;
    const height = 100;
    const barHeight = 20;
    const gap = 8;

    return (
      <View style={styles.chartContainer}>
        <ThemedText style={[styles.chartLabel, { color: theme.textSecondary }]}>{label}</ThemedText>
        <Svg width={width} height={height}>
          {data.map((item, index) => {
            const barWidth = (Math.abs(item.value) / maxValue) * (width - 80);
            const y = index * (barHeight + gap);
            return (
              <React.Fragment key={index}>
                <Rect
                  x={0}
                  y={y}
                  width={barWidth}
                  height={barHeight}
                  rx={4}
                  fill={chartColors[index % chartColors.length]}
                />
                <SvgText
                  x={barWidth + 8}
                  y={y + barHeight / 2 + 4}
                  fontSize={12}
                  fontWeight="600"
                  fill={theme.text}
                >
                  {format(item.value)}
                </SvgText>
              </React.Fragment>
            );
          })}
        </Svg>
      </View>
    );
  };

  if (isLoading) {
    return (
      <ThemedView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </ThemedView>
    );
  }

  if (analyses.length < 2) {
    return (
      <ThemedView style={styles.container}>
        <View style={[styles.emptyContainer, { paddingTop: headerHeight + Spacing.xl }]}>
          <Feather name="columns" size={48} color={theme.textSecondary} />
          <ThemedText style={[styles.emptyTitle, { color: theme.textSecondary }]}>
            Need More Properties
          </ThemedText>
          <ThemedText style={[styles.emptyText, { color: theme.textSecondary }]}>
            Save at least 2 property analyses to compare them side by side
          </ThemedText>
        </View>
      </ThemedView>
    );
  }

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: headerHeight + Spacing.md, paddingBottom: tabBarHeight + Spacing.xl },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <ThemedText style={[styles.subtitle, { color: theme.textSecondary }]}>
          Select up to 3 properties to compare
        </ThemedText>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.selectionRow}>
          {analyses.map((analysis) => (
            <Pressable
              key={analysis.id}
              onPress={() => toggleSelection(analysis.id)}
              style={[
                styles.selectionChip,
                {
                  backgroundColor: selected.includes(analysis.id) ? colors.primary : theme.backgroundDefault,
                  borderColor: selected.includes(analysis.id) ? colors.primary : theme.border,
                },
              ]}
            >
              <ThemedText
                style={[
                  styles.chipText,
                  { color: selected.includes(analysis.id) ? "#FFFFFF" : theme.text },
                ]}
                numberOfLines={1}
              >
                {analysis.location}
              </ThemedText>
            </Pressable>
          ))}
        </ScrollView>

        {selectedAnalyses.length >= 2 ? (
          <Animated.View entering={FadeInDown.duration(300)}>
            <View style={styles.comparisonGrid}>
              {selectedAnalyses.map((analysis, index) => (
                <View
                  key={analysis.id}
                  style={[
                    styles.propertyCard,
                    { backgroundColor: theme.backgroundDefault, borderColor: chartColors[index] },
                  ]}
                >
                  <View style={[styles.colorBar, { backgroundColor: chartColors[index] }]} />
                  <ThemedText style={styles.propertyLocation} numberOfLines={1}>
                    {analysis.location}
                  </ThemedText>
                  <ThemedText style={styles.propertyPrice}>
                    {formatCurrency(analysis.propertyPrice)}
                  </ThemedText>
                  <View
                    style={[
                      styles.verdictBadge,
                      { backgroundColor: getVerdictColor(analysis.verdict) + "20" },
                    ]}
                  >
                    <ThemedText
                      style={[styles.verdictText, { color: getVerdictColor(analysis.verdict) }]}
                    >
                      {analysis.verdict}
                    </ThemedText>
                  </View>
                </View>
              ))}
            </View>

            <View style={[styles.chartsSection, { backgroundColor: theme.backgroundDefault, borderColor: theme.border }]}>
              <ThemedText style={styles.sectionTitle}>Key Metrics Comparison</ThemedText>
              
              <ComparisonBarChart
                label="Net Cash Flow (Annual)"
                data={selectedAnalyses.map((a) => ({ value: a.netAnnualCashFlow, label: a.location }))}
                format={(v) => formatCurrency(v)}
              />

              <ComparisonBarChart
                label="Capital Gain"
                data={selectedAnalyses.map((a) => ({ value: a.capitalGain, label: a.location }))}
                format={(v) => formatCurrency(v)}
              />

              <ComparisonBarChart
                label="Cash-on-Cash ROI"
                data={selectedAnalyses.map((a) => ({ value: a.cashOnCashROI, label: a.location }))}
                format={(v) => `${v.toFixed(1)}%`}
              />
            </View>

            <View style={styles.legendSection}>
              {selectedAnalyses.map((analysis, index) => (
                <View key={analysis.id} style={styles.legendItem}>
                  <View style={[styles.legendDot, { backgroundColor: chartColors[index] }]} />
                  <ThemedText style={[styles.legendText, { color: theme.textSecondary }]} numberOfLines={1}>
                    {analysis.location}
                  </ThemedText>
                </View>
              ))}
            </View>
          </Animated.View>
        ) : (
          <View style={styles.selectMore}>
            <ThemedText style={{ color: theme.textSecondary }}>
              Select at least 2 properties to see comparison
            </ThemedText>
          </View>
        )}
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  loadingContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Spacing.xl,
    gap: Spacing.md,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: "600",
  },
  emptyText: {
    fontSize: 15,
    textAlign: "center",
  },
  subtitle: {
    fontSize: 14,
    textAlign: "center",
    marginBottom: Spacing.md,
  },
  selectionRow: {
    marginBottom: Spacing.lg,
  },
  selectionChip: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
    marginRight: Spacing.sm,
    maxWidth: 150,
  },
  chipText: {
    fontSize: 13,
    fontWeight: "500",
  },
  comparisonGrid: {
    flexDirection: "row",
    gap: Spacing.sm,
    marginBottom: Spacing.lg,
  },
  propertyCard: {
    flex: 1,
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 2,
    alignItems: "center",
    overflow: "hidden",
  },
  colorBar: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: 4,
  },
  propertyLocation: {
    fontSize: 12,
    fontWeight: "500",
    marginTop: Spacing.xs,
    textAlign: "center",
  },
  propertyPrice: {
    fontSize: 18,
    fontWeight: "700",
    marginTop: Spacing.xs,
  },
  verdictBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
    marginTop: Spacing.sm,
  },
  verdictText: {
    fontSize: 11,
    fontWeight: "600",
  },
  chartsSection: {
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    marginBottom: Spacing.md,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "600",
    marginBottom: Spacing.md,
  },
  chartContainer: {
    marginBottom: Spacing.md,
  },
  chartLabel: {
    fontSize: 12,
    fontWeight: "500",
    marginBottom: Spacing.xs,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  legendSection: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: Spacing.md,
    marginBottom: Spacing.lg,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  legendText: {
    fontSize: 13,
    maxWidth: 120,
  },
  selectMore: {
    alignItems: "center",
    paddingVertical: Spacing.xl,
  },
});
