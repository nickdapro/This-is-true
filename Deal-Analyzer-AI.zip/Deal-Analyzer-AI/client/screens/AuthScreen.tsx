import React, { useState, useEffect } from "react";
import {
  View,
  StyleSheet,
  Image,
  Pressable,
  ActivityIndicator,
  Switch,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as WebBrowser from "expo-web-browser";
import * as AuthSession from "expo-auth-session";
import * as Google from "expo-auth-session/providers/google";
import Animated, { FadeIn, FadeInDown, FadeInUp } from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Button } from "@/components/Button";
import { FormInput } from "@/components/FormInput";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/contexts/AuthContext";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";
import { validateEmail, validatePassword, validateName, getPasswordStrength } from "@/lib/auth";

WebBrowser.maybeCompleteAuthSession();

type AuthMode = "login" | "signup" | "forgot" | "reset";

export default function AuthScreen() {
  const insets = useSafeAreaInsets();
  const { theme, isDark } = useTheme();
  const colors = Colors[isDark ? "dark" : "light"];
  const { login, signup, loginWithGoogle, requestPasswordReset, resetPassword: doResetPassword } = useAuth();

  const [mode, setMode] = useState<AuthMode>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [name, setName] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [resetToken, setResetToken] = useState<string | null>(null);

  const [emailError, setEmailError] = useState<string | null>(null);
  const [passwordErrors, setPasswordErrors] = useState<string[]>([]);
  const [nameError, setNameError] = useState<string | null>(null);
  const [passwordStrength, setPasswordStrength] = useState<{ score: number; label: string; color: string } | null>(null);

  useEffect(() => {
    if (email) {
      const result = validateEmail(email);
      setEmailError(result.isValid ? null : result.error || null);
    } else {
      setEmailError(null);
    }
  }, [email]);

  useEffect(() => {
    if (password && mode === "signup") {
      const result = validatePassword(password);
      setPasswordErrors(result.errors);
      setPasswordStrength(result.strength || null);
    } else {
      setPasswordErrors([]);
      setPasswordStrength(null);
    }
  }, [password, mode]);

  useEffect(() => {
    if (name && mode === "signup") {
      const result = validateName(name);
      setNameError(result.isValid ? null : result.error || null);
    } else {
      setNameError(null);
    }
  }, [name, mode]);

  const handleSubmit = async () => {
    setError(null);
    setSuccessMessage(null);
    
    if (mode === "forgot") {
      if (!email.trim()) {
        setError("Please enter your email address");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        return;
      }
      
      const emailValidation = validateEmail(email);
      if (!emailValidation.isValid) {
        setError(emailValidation.error || "Invalid email");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        return;
      }
      
      setIsLoading(true);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      
      try {
        const result = await requestPasswordReset(email.trim());
        if (result.token) {
          setResetToken(result.token);
          setMode("reset");
          setPassword("");
          setConfirmPassword("");
          setSuccessMessage("Reset link generated. Enter your new password.");
        } else {
          setSuccessMessage("If an account exists with this email, a reset link has been sent.");
        }
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to send reset email");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      } finally {
        setIsLoading(false);
      }
      return;
    }
    
    if (mode === "reset") {
      if (!password.trim() || !confirmPassword.trim()) {
        setError("Please enter and confirm your new password");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        return;
      }
      
      if (password !== confirmPassword) {
        setError("Passwords do not match");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        return;
      }
      
      const passwordValidation = validatePassword(password);
      if (!passwordValidation.isValid) {
        setError(passwordValidation.errors[0]);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        return;
      }
      
      if (!resetToken) {
        setError("Invalid reset session. Please try again.");
        setMode("forgot");
        return;
      }
      
      setIsLoading(true);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      
      try {
        await doResetPassword(resetToken, password);
        setSuccessMessage("Password reset successfully! Please sign in.");
        setMode("login");
        setPassword("");
        setConfirmPassword("");
        setResetToken(null);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to reset password");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      } finally {
        setIsLoading(false);
      }
      return;
    }
    
    if (!email.trim() || !password.trim()) {
      setError("Please fill in all fields");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }
    
    if (mode === "signup" && !name.trim()) {
      setError("Please enter your name");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }
    
    const emailValidation = validateEmail(email);
    if (!emailValidation.isValid) {
      setError(emailValidation.error || "Invalid email");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }
    
    if (mode === "signup") {
      const passwordValidation = validatePassword(password);
      if (!passwordValidation.isValid) {
        setError(passwordValidation.errors[0]);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        return;
      }
      
      const nameValidation = validateName(name);
      if (!nameValidation.isValid) {
        setError(nameValidation.error || "Invalid name");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        return;
      }
    }

    setIsLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      if (mode === "login") {
        await login(email.trim(), password, rememberMe);
      } else {
        await signup(email.trim(), password, name.trim());
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Authentication failed");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setIsGoogleLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      setError("Google Sign-In requires OAuth credentials configuration. Please use email/password for now.");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Google sign-in failed");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setIsGoogleLoading(false);
    }
  };

  const toggleMode = (newMode: AuthMode) => {
    setMode(newMode);
    setError(null);
    setSuccessMessage(null);
    if (newMode !== "reset") {
      setResetToken(null);
    }
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const getTitle = () => {
    switch (mode) {
      case "login": return "Welcome Back";
      case "signup": return "Create Account";
      case "forgot": return "Reset Password";
      case "reset": return "New Password";
    }
  };

  const getSubtitle = () => {
    switch (mode) {
      case "login": return "Sign in to continue analyzing deals";
      case "signup": return "Start making smarter investment decisions";
      case "forgot": return "Enter your email to receive a reset link";
      case "reset": return "Choose a strong password for your account";
    }
  };

  const getButtonText = () => {
    if (isLoading) {
      switch (mode) {
        case "login": return "Signing in...";
        case "signup": return "Creating account...";
        case "forgot": return "Sending...";
        case "reset": return "Resetting...";
      }
    }
    switch (mode) {
      case "login": return "Sign In";
      case "signup": return "Create Account";
      case "forgot": return "Send Reset Link";
      case "reset": return "Reset Password";
    }
  };

  return (
    <ThemedView style={styles.container}>
      <KeyboardAwareScrollViewCompat
        style={styles.scrollView}
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: insets.top + Spacing.xl,
            paddingBottom: insets.bottom + Spacing.xl,
          },
        ]}
      >
        <Animated.View entering={FadeIn.duration(400)} style={styles.header}>
          <Image
            source={require("../../assets/images/icon.png")}
            style={styles.logo}
            resizeMode="contain"
          />
          <ThemedText type="h2" style={styles.title}>
            DealLens Pro
          </ThemedText>
          <ThemedText style={[styles.tagline, { color: theme.textSecondary }]}>
            AI-Powered Multi-Asset Investment Analysis
          </ThemedText>
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(200).duration(400)}>
          <View
            style={[
              styles.card,
              {
                backgroundColor: theme.backgroundDefault,
                borderColor: theme.border,
              },
            ]}
          >
            <ThemedText type="h4" style={styles.cardTitle}>
              {getTitle()}
            </ThemedText>
            <ThemedText style={[styles.cardSubtitle, { color: theme.textSecondary }]}>
              {getSubtitle()}
            </ThemedText>

            {(mode === "login" || mode === "signup") ? (
              <>
                <Pressable
                  onPress={handleGoogleSignIn}
                  disabled={isGoogleLoading}
                  style={({ pressed }) => [
                    styles.googleButton,
                    { 
                      backgroundColor: theme.backgroundSecondary, 
                      borderColor: theme.border,
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}
                >
                  {isGoogleLoading ? (
                    <ActivityIndicator size="small" color={theme.text} />
                  ) : (
                    <>
                      <View style={styles.googleIcon}>
                        <ThemedText style={{ fontSize: 16, fontWeight: "700", color: "#FFFFFF" }}>G</ThemedText>
                      </View>
                      <ThemedText style={styles.googleText}>
                        Continue with Google
                      </ThemedText>
                    </>
                  )}
                </Pressable>

                <View style={styles.dividerContainer}>
                  <View style={[styles.dividerLine, { backgroundColor: theme.border }]} />
                  <ThemedText style={[styles.dividerText, { color: theme.textSecondary }]}>
                    or
                  </ThemedText>
                  <View style={[styles.dividerLine, { backgroundColor: theme.border }]} />
                </View>
              </>
            ) : null}

            {mode === "signup" ? (
              <View style={styles.inputGroup}>
                <FormInput
                  label="Full Name"
                  value={name}
                  onChangeText={setName}
                  placeholder="John Smith"
                  autoCapitalize="words"
                />
                {nameError ? (
                  <ThemedText style={[styles.fieldError, { color: colors.danger }]}>
                    {nameError}
                  </ThemedText>
                ) : null}
              </View>
            ) : null}

            {mode !== "reset" ? (
              <View style={styles.inputGroup}>
                <FormInput
                  label="Email"
                  value={email}
                  onChangeText={setEmail}
                  placeholder="you@example.com"
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
                {emailError && email.length > 0 ? (
                  <ThemedText style={[styles.fieldError, { color: colors.danger }]}>
                    {emailError}
                  </ThemedText>
                ) : null}
              </View>
            ) : null}

            {mode !== "forgot" ? (
              <View style={styles.inputGroup}>
                <View style={styles.passwordContainer}>
                  <FormInput
                    label={mode === "reset" ? "New Password" : "Password"}
                    value={password}
                    onChangeText={setPassword}
                    placeholder="••••••••"
                    secureTextEntry={!showPassword}
                    autoCapitalize="none"
                  />
                  <Pressable
                    style={styles.eyeButton}
                    onPress={() => setShowPassword(!showPassword)}
                  >
                    <Feather
                      name={showPassword ? "eye-off" : "eye"}
                      size={20}
                      color={theme.textSecondary}
                    />
                  </Pressable>
                </View>
                
                {(mode === "signup" || mode === "reset") && passwordStrength ? (
                  <View style={styles.strengthContainer}>
                    <View style={styles.strengthBar}>
                      {[1, 2, 3, 4, 5, 6].map((i) => (
                        <View
                          key={i}
                          style={[
                            styles.strengthSegment,
                            {
                              backgroundColor: i <= passwordStrength.score
                                ? passwordStrength.color
                                : theme.border,
                            },
                          ]}
                        />
                      ))}
                    </View>
                    <ThemedText style={[styles.strengthLabel, { color: passwordStrength.color }]}>
                      {passwordStrength.label}
                    </ThemedText>
                  </View>
                ) : null}
                
                {(mode === "signup" || mode === "reset") && passwordErrors.length > 0 && password.length > 0 ? (
                  <View style={styles.passwordRequirements}>
                    {["At least 8 characters", "One uppercase letter", "One lowercase letter", "One number"].map((req, i) => {
                      const passed = !passwordErrors.includes(req);
                      return (
                        <View key={i} style={styles.requirementRow}>
                          <Feather
                            name={passed ? "check-circle" : "circle"}
                            size={14}
                            color={passed ? colors.success : theme.textSecondary}
                          />
                          <ThemedText 
                            style={[
                              styles.requirementText, 
                              { color: passed ? colors.success : theme.textSecondary }
                            ]}
                          >
                            {req}
                          </ThemedText>
                        </View>
                      );
                    })}
                  </View>
                ) : null}
              </View>
            ) : null}

            {mode === "reset" ? (
              <View style={styles.inputGroup}>
                <FormInput
                  label="Confirm Password"
                  value={confirmPassword}
                  onChangeText={setConfirmPassword}
                  placeholder="••••••••"
                  secureTextEntry={!showPassword}
                  autoCapitalize="none"
                />
                {confirmPassword.length > 0 && password !== confirmPassword ? (
                  <ThemedText style={[styles.fieldError, { color: colors.danger }]}>
                    Passwords do not match
                  </ThemedText>
                ) : null}
              </View>
            ) : null}

            {mode === "login" ? (
              <View style={styles.loginOptions}>
                <View style={styles.rememberRow}>
                  <Switch
                    value={rememberMe}
                    onValueChange={setRememberMe}
                    trackColor={{ false: theme.border, true: colors.primary }}
                    thumbColor="#FFFFFF"
                  />
                  <ThemedText style={[styles.rememberText, { color: theme.textSecondary }]}>
                    Remember me for 30 days
                  </ThemedText>
                </View>
                <Pressable onPress={() => toggleMode("forgot")}>
                  <ThemedText style={[styles.forgotText, { color: colors.primary }]}>
                    Forgot password?
                  </ThemedText>
                </Pressable>
              </View>
            ) : null}

            {successMessage ? (
              <Animated.View 
                entering={FadeInUp.duration(300)}
                style={[styles.messageContainer, { backgroundColor: colors.successBackground }]}
              >
                <Feather name="check-circle" size={16} color={colors.success} />
                <ThemedText style={[styles.messageText, { color: colors.success }]}>
                  {successMessage}
                </ThemedText>
              </Animated.View>
            ) : null}

            {error ? (
              <Animated.View 
                entering={FadeInUp.duration(300)}
                style={[styles.messageContainer, { backgroundColor: colors.dangerBackground }]}
              >
                <Feather name="alert-circle" size={16} color={colors.danger} />
                <ThemedText style={[styles.messageText, { color: colors.danger }]}>
                  {error}
                </ThemedText>
              </Animated.View>
            ) : null}

            <Button 
              onPress={handleSubmit} 
              disabled={isLoading} 
              style={[styles.submitButton, { backgroundColor: colors.primary }]}
            >
              {isLoading ? (
                <View style={styles.loadingRow}>
                  <ActivityIndicator color="#FFFFFF" size="small" />
                  <ThemedText style={styles.buttonText}>
                    {getButtonText()}
                  </ThemedText>
                </View>
              ) : (
                <ThemedText style={styles.buttonText}>
                  {getButtonText()}
                </ThemedText>
              )}
            </Button>

            {mode === "login" ? (
              <Pressable onPress={() => toggleMode("signup")} style={styles.toggleButton}>
                <ThemedText style={[styles.toggleText, { color: theme.textSecondary }]}>
                  Don't have an account?{" "}
                  <ThemedText style={{ color: colors.primary, fontWeight: "600" }}>
                    Sign Up
                  </ThemedText>
                </ThemedText>
              </Pressable>
            ) : mode === "signup" ? (
              <Pressable onPress={() => toggleMode("login")} style={styles.toggleButton}>
                <ThemedText style={[styles.toggleText, { color: theme.textSecondary }]}>
                  Already have an account?{" "}
                  <ThemedText style={{ color: colors.primary, fontWeight: "600" }}>
                    Sign In
                  </ThemedText>
                </ThemedText>
              </Pressable>
            ) : (
              <Pressable onPress={() => toggleMode("login")} style={styles.toggleButton}>
                <ThemedText style={[styles.toggleText, { color: theme.textSecondary }]}>
                  Back to{" "}
                  <ThemedText style={{ color: colors.primary, fontWeight: "600" }}>
                    Sign In
                  </ThemedText>
                </ThemedText>
              </Pressable>
            )}
          </View>
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(400).duration(400)} style={styles.features}>
          <View style={styles.featureRow}>
            <Feather name="shield" size={18} color={colors.success} />
            <ThemedText style={[styles.featureText, { color: theme.textSecondary }]}>
              Bank-grade security
            </ThemedText>
          </View>
          <View style={styles.featureRow}>
            <Feather name="zap" size={18} color={colors.primary} />
            <ThemedText style={[styles.featureText, { color: theme.textSecondary }]}>
              AI-powered analysis
            </ThemedText>
          </View>
          <View style={styles.featureRow}>
            <Feather name="globe" size={18} color={colors.chartBlue} />
            <ThemedText style={[styles.featureText, { color: theme.textSecondary }]}>
              Multi-asset support
            </ThemedText>
          </View>
        </Animated.View>
      </KeyboardAwareScrollViewCompat>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  header: {
    alignItems: "center",
    marginBottom: Spacing.xl,
  },
  logo: {
    width: 80,
    height: 80,
    marginBottom: Spacing.md,
    borderRadius: 16,
  },
  title: {
    marginBottom: Spacing.xs,
  },
  tagline: {
    fontSize: 15,
    textAlign: "center",
  },
  card: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    marginBottom: Spacing.xl,
  },
  cardTitle: {
    textAlign: "center",
    marginBottom: Spacing.xs,
  },
  cardSubtitle: {
    fontSize: 14,
    textAlign: "center",
    marginBottom: Spacing.lg,
  },
  googleButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  googleIcon: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: "#4285F4",
    alignItems: "center",
    justifyContent: "center",
  },
  googleText: {
    fontSize: 16,
    fontWeight: "500",
  },
  dividerContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.md,
    gap: Spacing.md,
  },
  dividerLine: {
    flex: 1,
    height: 1,
  },
  dividerText: {
    fontSize: 12,
    textTransform: "uppercase",
    letterSpacing: 1,
  },
  inputGroup: {
    marginBottom: Spacing.sm,
  },
  passwordContainer: {
    position: "relative",
  },
  eyeButton: {
    position: "absolute",
    right: Spacing.md,
    top: 34,
    padding: Spacing.sm,
  },
  strengthContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    marginTop: Spacing.xs,
  },
  strengthBar: {
    flexDirection: "row",
    gap: 3,
    flex: 1,
  },
  strengthSegment: {
    flex: 1,
    height: 4,
    borderRadius: 2,
  },
  strengthLabel: {
    fontSize: 11,
    fontWeight: "600",
    minWidth: 50,
    textAlign: "right",
  },
  passwordRequirements: {
    marginTop: Spacing.sm,
    gap: 4,
  },
  requirementRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
  },
  requirementText: {
    fontSize: 12,
  },
  fieldError: {
    fontSize: 12,
    marginTop: 4,
  },
  loginOptions: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  rememberRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  rememberText: {
    fontSize: 14,
  },
  forgotText: {
    fontSize: 14,
    fontWeight: "500",
  },
  messageContainer: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.md,
    borderRadius: BorderRadius.sm,
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  messageText: {
    flex: 1,
    fontSize: 14,
  },
  submitButton: {
    marginTop: Spacing.sm,
  },
  loadingRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  buttonText: {
    color: "#FFFFFF",
    fontWeight: "600",
    fontSize: 16,
  },
  toggleButton: {
    marginTop: Spacing.md,
    alignItems: "center",
  },
  toggleText: {
    fontSize: 14,
  },
  features: {
    flexDirection: "row",
    justifyContent: "center",
    gap: Spacing.lg,
    flexWrap: "wrap",
  },
  featureRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
  },
  featureText: {
    fontSize: 13,
  },
});
