import { sql } from "drizzle-orm";
import { pgTable, text, varchar, serial, integer, real, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password"),
  name: text("name").notNull(),
  googleId: text("google_id"),
  avatarUrl: text("avatar_url"),
  propertiesAnalyzed: integer("properties_analyzed").default(0).notNull(),
  currentStreak: integer("current_streak").default(0).notNull(),
  lastAnalysisDate: timestamp("last_analysis_date"),
  badges: text("badges").default("[]"),
  portfolioHealthLevel: integer("portfolio_health_level").default(0),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at").notNull(),
});

export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  token: varchar("token", { length: 64 }).notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  usedAt: timestamp("used_at"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const savedAnalyses = pgTable("saved_analyses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  assetType: text("asset_type").notNull().default("real_estate"),
  assetName: text("asset_name").notNull().default(""),
  propertyPrice: real("property_price").notNull(),
  location: text("location").notNull(),
  propertyType: text("property_type").notNull(),
  numberOfUnits: integer("number_of_units").notNull(),
  rentPerUnitPerWeek: real("rent_per_unit_per_week").notNull(),
  expensesPercent: real("expenses_percent").notNull(),
  expectedGrowthPercent: real("expected_growth_percent").notNull(),
  investmentPeriod: integer("investment_period").notNull(),
  annualRentalIncome: real("annual_rental_income").notNull(),
  annualExpenses: real("annual_expenses").notNull(),
  netAnnualCashFlow: real("net_annual_cash_flow").notNull(),
  futureValue: real("future_value").notNull(),
  capitalGain: real("capital_gain").notNull(),
  cashOnCashROI: real("cash_on_cash_roi").notNull(),
  grossYield: real("gross_yield"),
  netYield: real("net_yield"),
  dealLensScore: integer("deallens_score").default(0),
  riskScore: integer("risk_score").default(50),
  yieldScore: integer("yield_score").default(50),
  growthScore: integer("growth_score").default(50),
  liquidityScore: integer("liquidity_score").default(50),
  verdict: text("verdict").notNull(),
  riskLevel: text("risk_level").notNull(),
  bulletPoints: text("bullet_points").notNull(),
  recommendation: text("recommendation").notNull(),
  strengths: text("strengths").default("[]"),
  weaknesses: text("weaknesses").default("[]"),
  risks: text("risks").default("[]"),
  confidenceLevel: real("confidence_level").default(0.8),
  photoUrl: text("photo_url"),
  shareToken: text("share_token"),
  suburb: text("suburb"),
  postcode: text("postcode"),
  state: text("state"),
  medianPrice: real("median_price"),
  medianRent: real("median_rent"),
  locationScore: integer("location_score").default(50),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const stockAnalyses = pgTable("stock_analyses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  ticker: text("ticker").notNull(),
  companyName: text("company_name").notNull(),
  currentPrice: real("current_price").notNull(),
  purchasePrice: real("purchase_price"),
  quantity: integer("quantity").default(1),
  marketCap: real("market_cap"),
  peRatio: real("pe_ratio"),
  dividendYield: real("dividend_yield"),
  fiftyTwoWeekHigh: real("fifty_two_week_high"),
  fiftyTwoWeekLow: real("fifty_two_week_low"),
  sector: text("sector"),
  industry: text("industry"),
  dealLensScore: integer("deallens_score").default(0),
  riskScore: integer("risk_score").default(50),
  yieldScore: integer("yield_score").default(50),
  growthScore: integer("growth_score").default(50),
  liquidityScore: integer("liquidity_score").default(80),
  verdict: text("verdict").notNull(),
  riskLevel: text("risk_level").notNull(),
  recommendation: text("recommendation").notNull(),
  aiSummary: text("ai_summary"),
  strengths: text("strengths").default("[]"),
  weaknesses: text("weaknesses").default("[]"),
  confidenceLevel: real("confidence_level").default(0.8),
  shareToken: text("share_token"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const cryptoAnalyses = pgTable("crypto_analyses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  symbol: text("symbol").notNull(),
  name: text("name").notNull(),
  currentPrice: real("current_price").notNull(),
  purchasePrice: real("purchase_price"),
  quantity: real("quantity").default(1),
  marketCap: real("market_cap"),
  volume24h: real("volume_24h"),
  priceChange24h: real("price_change_24h"),
  priceChange7d: real("price_change_7d"),
  allTimeHigh: real("all_time_high"),
  circulatingSupply: real("circulating_supply"),
  dealLensScore: integer("deallens_score").default(0),
  riskScore: integer("risk_score").default(70),
  yieldScore: integer("yield_score").default(0),
  growthScore: integer("growth_score").default(50),
  liquidityScore: integer("liquidity_score").default(90),
  verdict: text("verdict").notNull(),
  riskLevel: text("risk_level").notNull(),
  recommendation: text("recommendation").notNull(),
  aiSummary: text("ai_summary"),
  strengths: text("strengths").default("[]"),
  weaknesses: text("weaknesses").default("[]"),
  confidenceLevel: real("confidence_level").default(0.7),
  shareToken: text("share_token"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const commodityAnalyses = pgTable("commodity_analyses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  type: text("type").notNull(),
  currentPrice: real("current_price").notNull(),
  purchasePrice: real("purchase_price"),
  quantity: real("quantity").default(1),
  unit: text("unit").default("oz"),
  priceChange30d: real("price_change_30d"),
  priceChange1y: real("price_change_1y"),
  dealLensScore: integer("deallens_score").default(0),
  riskScore: integer("risk_score").default(40),
  yieldScore: integer("yield_score").default(0),
  growthScore: integer("growth_score").default(50),
  liquidityScore: integer("liquidity_score").default(70),
  verdict: text("verdict").notNull(),
  riskLevel: text("risk_level").notNull(),
  recommendation: text("recommendation").notNull(),
  aiSummary: text("ai_summary"),
  strengths: text("strengths").default("[]"),
  weaknesses: text("weaknesses").default("[]"),
  confidenceLevel: real("confidence_level").default(0.75),
  shareToken: text("share_token"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  password: true,
  name: true,
});

export const insertSessionSchema = createInsertSchema(sessions);

export const insertSavedAnalysisSchema = createInsertSchema(savedAnalyses).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Session = typeof sessions.$inferSelect;
export type SavedAnalysis = typeof savedAnalyses.$inferSelect;
export type StockAnalysis = typeof stockAnalyses.$inferSelect;
export type CryptoAnalysis = typeof cryptoAnalyses.$inferSelect;
export type CommodityAnalysis = typeof commodityAnalyses.$inferSelect;
export type InsertSavedAnalysis = z.infer<typeof insertSavedAnalysisSchema>;
