# DealLens

## Overview

DealLens is a property investment analysis tool designed for Australian property investors. It allows users to quickly analyze deal viability without complex spreadsheets by combining financial calculations with AI-powered insights. The app provides instant visual judgments on property deals with color-coded risk levels and clear recommendations (Buy, Negotiate, or Walk away).

The application is built as a cross-platform Expo React Native app with a Node.js Express backend, supporting web, iOS, and Android platforms.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: Expo SDK 54 with React Native 0.81, targeting web, iOS, and Android platforms.

**State Management**: 
- React Query (@tanstack/react-query) for server state and API caching
- React Context for authentication (AuthContext) and theming (ThemeContext)
- AsyncStorage for persistent local storage (sessions, theme preferences)

**Navigation**: React Navigation v7 with:
- Native stack navigator for auth flow
- Bottom tab navigator for main app screens (Analyze, Dashboard, Compare, Profile)
- Blur effects on iOS tab bar using expo-blur

**UI Approach**:
- Custom themed components (ThemedText, ThemedView, Button, Card, FormInput)
- Reanimated for smooth animations
- Feather icons from @expo/vector-icons
- SVG charts for data visualization (CashFlowChart, CapitalGainsChart, YieldDonutChart)
- Light/dark theme support with system preference detection

**Design Philosophy**: Brutally minimal with sharp precision - maximum whitespace, essential elements only, sharp contrast with gold accent color (#D4AF37) for key actions.

### Backend Architecture

**Framework**: Express.js 5 with TypeScript, compiled via esbuild for production.

**API Design**: RESTful JSON API with session-based authentication using Bearer tokens.

**Core Routes**:
- `/api/auth/*` - Authentication (login, signup, logout, session validation)
- `/api/analyze` - Property deal analysis with AI-powered verdicts
- `/api/analyses` - CRUD operations for saved analyses
- `/api/user/*` - User profile and statistics

**AI Integration**: OpenAI API via Replit AI Integrations for generating property analysis verdicts, risk assessments, and recommendations.

### Data Storage

**Database**: PostgreSQL via Drizzle ORM with the following schema:
- `users` - User accounts with email/password auth, gamification stats (properties analyzed, streaks)
- `sessions` - Session tokens with expiration
- `saved_analyses` - Complete property analysis records including inputs, calculations, and AI verdicts
- `conversations` / `messages` - Chat storage for AI integrations (voice/text)

**Migrations**: Managed via drizzle-kit with migrations stored in `/migrations` directory.

### Authentication

**Method**: Session-based authentication with SHA-256 password hashing.
- Sessions stored in database with configurable expiration (1 day default, 30 days with "remember me")
- Client stores session ID and user data in AsyncStorage
- Bearer token passed in Authorization header for API requests

### Key Design Decisions

1. **Single-page analysis flow**: Main screen handles input, calculation, and results display in one focused view to minimize cognitive load.

2. **Hybrid platform support**: Using Expo with web export capability allows single codebase deployment across web and mobile while leveraging native features where available.

3. **Path aliases**: `@/` maps to client code, `@shared/` maps to shared code, enabling clean imports across the codebase.

4. **Gamification**: Built-in achievement system tracking properties analyzed and analysis streaks to encourage engagement.

## External Dependencies

### AI Services
- **OpenAI API** (via Replit AI Integrations): Powers property analysis verdicts, risk assessments, and recommendations. Configured through `AI_INTEGRATIONS_OPENAI_API_KEY` and `AI_INTEGRATIONS_OPENAI_BASE_URL` environment variables.

### Database
- **PostgreSQL**: Primary data store, connection via `DATABASE_URL` environment variable.

### Third-Party Libraries
- **Drizzle ORM**: Type-safe database queries with PostgreSQL adapter
- **React Query**: Server state management and caching
- **Expo SDK**: Cross-platform mobile framework with splash screen, haptics, blur effects
- **React Navigation**: Native navigation with bottom tabs and stack navigators
- **React Native Reanimated**: High-performance animations
- **Zod**: Schema validation for API inputs (via drizzle-zod)

### Replit Integrations
The project includes pre-built Replit integration modules in `server/replit_integrations/` for:
- Audio/voice chat with streaming playback
- Batch processing with rate limiting
- Text chat with conversation storage
- Image generation

These are available but not currently integrated into the main application flow.