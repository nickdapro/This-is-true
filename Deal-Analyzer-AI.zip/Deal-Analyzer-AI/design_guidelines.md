# DealLens Design Guidelines

## Brand Identity

**Purpose**: DealLens helps Australian property investors quickly analyze deal viability without complex spreadsheets. It's a calculator with clarity - numbers paired with AI-powered insight.

**Aesthetic Direction**: **Brutally minimal with sharp precision**
- Financial tools demand trust and clarity, not decoration
- Maximum whitespace, essential elements only
- Sharp contrast and precise alignment convey accuracy
- One bold accent color for key actions/verdicts

**Memorable Element**: The AI verdict appears as a large, unmissable card with color-coded risk levels - users will remember the instant visual judgment before reading details.

## Navigation Architecture

**Single-Page Application** - No navigation needed. Everything happens on one focused screen with sections revealed after analysis.

## Screen Specification

### Main Screen (Only Screen)

**Purpose**: Input property details, calculate returns, view AI analysis.

**Layout**:
- Fixed header with app branding "DealLens" (left-aligned, bold)
- Centered content container (max-width: 600px on desktop)
- Sticky "Analyze Deal" button at bottom on mobile, inline on desktop
- No scrolling until results appear

**Sections** (appear sequentially):

1. **Input Form** (always visible)
   - Clean vertical form with grouped fields
   - Labels above inputs (not placeholder text)
   - Field groupings:
     - Property Details: Price, Location, Type, Units
     - Income: Rent per Unit/Week
     - Assumptions: Expenses %, Growth %, Investment Period
   - Default values pre-filled for assumptions
   - Primary action button: "Analyze Deal"

2. **Numbers Summary** (appears after calculation)
   - Grid layout: 2 columns on desktop, 1 on mobile
   - Metric cards with label + large number
   - Metrics: Annual Income, Expenses, Cash Flow, Future Value, Capital Gain
   - Use semantic colors: positive cash flow (green), negative (red)

3. **AI Verdict Card** (prominent, color-coded)
   - Large card with background matching risk level
   - Verdict text (Good/Neutral/Bad) as headline
   - Risk badge (Low/Medium/High) below

4. **Risk Explanation** (bulleted list, 3 points)
   - Simple bullet points, generous line height

5. **Recommendation** (final action)
   - Single sentence, bold text
   - Color-coded: Buy (green), Negotiate (amber), Walk Away (red)

**Empty/Initial State**: Clean form with welcoming subheading: "Enter property details to see if the numbers make sense"

**Error States**: Inline validation messages in red below relevant fields

## Color Palette

**Primary**: #2563EB (Strong blue - confidence, clarity)
**Surface**: #FFFFFF (Pure white background)
**Surface Secondary**: #F8FAFC (Subtle gray for cards)
**Border**: #E2E8F0 (Soft dividers)

**Text**:
- Primary: #0F172A (Almost black)
- Secondary: #64748B (Muted gray for labels)

**Semantic**:
- Success (Good/Buy): #10B981
- Warning (Neutral/Negotiate): #F59E0B
- Danger (Bad/Walk Away): #EF4444
- Info: #3B82F6

**Risk Level Backgrounds** (subtle tints):
- Low Risk: #ECFDF5 (green tint)
- Medium Risk: #FEF3C7 (amber tint)
- High Risk: #FEF2F2 (red tint)

## Typography

**Font**: System stack (-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto)

**Type Scale**:
- App Title: 24px, Bold
- Section Headings: 20px, Semibold
- Metric Labels: 14px, Medium, uppercase, letter-spacing 0.5px
- Metric Values: 32px, Bold
- Verdict Headline: 28px, Bold
- Body/Inputs: 16px, Regular
- Input Labels: 14px, Medium

## Visual Design

**Spacing System**: 
- xs: 4px, sm: 8px, md: 16px, lg: 24px, xl: 32px, 2xl: 48px

**Cards**: 
- Background: Surface Secondary
- Border: 1px solid Border color
- Border radius: 8px
- Padding: lg
- Box shadow: NONE (keep minimal)

**Buttons**:
- Primary: Background Primary color, white text, 48px height, 16px border-radius
- Hover: Darken by 10%
- Active: Darken by 20%, slight scale (0.98)
- Full-width on mobile, auto-width on desktop (min 200px)

**Form Inputs**:
- Height: 48px
- Border: 1px Border color
- Border radius: 6px
- Padding: 12px
- Focus: 2px solid Primary color
- Number inputs: Right-aligned text for currency/percentages

**Icons**: Use simple iconography for input field prefixes ($ for price, % for percentages). Material Icons or Lucide recommended.

## Assets to Generate

1. **app-icon.png**
   - Description: Simple geometric icon - overlapping squares representing property/deal layers, Primary color on white
   - WHERE USED: Browser favicon, potential PWA icon

2. **empty-state.svg**
   - Description: Minimal line illustration of calculator + property outline
   - WHERE USED: Above input form on initial load (subtle, gray)

3. **verdict-good.svg**
   - Description: Simple checkmark in circle
   - WHERE USED: AI Verdict Card when deal is "Good"

4. **verdict-neutral.svg**
   - Description: Dash or equal sign in circle
   - WHERE USED: AI Verdict Card when deal is "Neutral"

5. **verdict-bad.svg**
   - Description: X or cross in circle
   - WHERE USED: AI Verdict Card when deal is "Bad"

## Responsive Behavior

**Mobile (<640px)**:
- Single column layout
- Full-width buttons
- Sticky analyze button at bottom
- Stack metric cards vertically

**Desktop (≥640px)**:
- Centered container (max 600px)
- 2-column metric grid
- Inline buttons
- More generous vertical spacing